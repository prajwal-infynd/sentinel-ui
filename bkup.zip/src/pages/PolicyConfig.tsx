import { motion } from "framer-motion";
import { Shield, Globe, AlertTriangle, Newspaper } from "lucide-react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const watchlists = [
  { name: "OFAC SDN List", region: "United States", enabled: true },
  { name: "EU Consolidated Sanctions", region: "European Union", enabled: true },
  { name: "UN Security Council", region: "International", enabled: true },
  { name: "UK HMT Sanctions", region: "United Kingdom", enabled: true },
  { name: "FATF High-Risk Jurisdictions", region: "International", enabled: false },
  { name: "Local Law Enforcement Notices", region: "Multi-jurisdiction", enabled: false },
  { name: "Interpol Red Notices", region: "International", enabled: true },
  { name: "World Bank Debarment List", region: "International", enabled: false },
];

const mediaCategories = [
  "Financial Crime", "Fraud", "Corruption", "Money Laundering", "Tax Evasion",
  "Terrorism Financing", "Sanctions Violations", "Bribery", "Environmental Crime",
];

const PolicyConfig = () => {
  const [lists, setLists] = useState(watchlists);
  const [confidence, setConfidence] = useState([75]);
  const [severity, setSeverity] = useState([60]);
  const [selectedMedia, setSelectedMedia] = useState(["Financial Crime", "Fraud", "Money Laundering", "Terrorism Financing"]);

  const toggle = (i: number) => {
    const updated = [...lists];
    updated[i] = { ...updated[i], enabled: !updated[i].enabled };
    setLists(updated);
  };

  const toggleMedia = (cat: string) => {
    setSelectedMedia(prev => prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]);
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6 max-w-4xl">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <h1 className="text-2xl font-bold tracking-tight mb-1">Policy Configuration</h1>
          <p className="text-sm text-muted-foreground">Configure screening rules, watchlists, and alert thresholds</p>
        </motion.div>

        {/* Watchlists */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="rounded-xl bg-card shadow-sm p-6"
        >
          <h3 className="font-semibold mb-4 flex items-center gap-2"><Shield className="h-4 w-4 text-primary" /> Watchlist Sources</h3>
          <div className="space-y-3">
            {lists.map((list, i) => (
              <div key={list.name} className="flex items-center justify-between py-2 border-b last:border-0">
                <div>
                  <div className="text-sm font-medium">{list.name}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <Globe className="h-3 w-3" />{list.region}
                  </div>
                </div>
                <Switch checked={list.enabled} onCheckedChange={() => toggle(i)} />
              </div>
            ))}
          </div>
        </motion.div>

        {/* Thresholds */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="rounded-xl bg-card shadow-sm p-6 space-y-6"
        >
          <h3 className="font-semibold flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-warning" /> Alert Thresholds</h3>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm">Matching Confidence Threshold</span>
              <span className="text-sm font-mono font-bold">{confidence[0]}%</span>
            </div>
            <Slider value={confidence} onValueChange={setConfidence} max={100} min={30} step={5} />
            <p className="text-xs text-muted-foreground mt-1">Matches below this threshold will not generate alerts</p>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm">Alert Severity Escalation</span>
              <span className="text-sm font-mono font-bold">{severity[0]}%</span>
            </div>
            <Slider value={severity} onValueChange={setSeverity} max={100} min={20} step={5} />
            <p className="text-xs text-muted-foreground mt-1">Scores above this threshold trigger high-severity alerts</p>
          </div>
        </motion.div>

        {/* Media Categories */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="rounded-xl bg-card shadow-sm p-6"
        >
          <h3 className="font-semibold mb-4 flex items-center gap-2"><Newspaper className="h-4 w-4 text-accent" /> Adverse Media Categories</h3>
          <div className="flex flex-wrap gap-2">
            {mediaCategories.map(cat => (
              <Badge key={cat}
                variant={selectedMedia.includes(cat) ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => toggleMedia(cat)}
              >
                {cat}
              </Badge>
            ))}
          </div>
        </motion.div>

        <Button size="lg" className="w-full">Save Policy Configuration</Button>
      </div>
    </DashboardLayout>
  );
};

export default PolicyConfig;
