import { motion } from "framer-motion";
import { Database, ArrowRight, CheckCircle2, Layers, GitBranch, FileText, Shield, Plug } from "lucide-react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";

const pipelineSteps = [
  { label: "Raw Sources", icon: Database, desc: "350+ global sanctions & media feeds" },
  { label: "S3 Landing", icon: Layers, desc: "Raw data lake ingestion" },
  { label: "Parsing", icon: FileText, desc: "Format-specific extraction" },
  { label: "Standardisation", icon: GitBranch, desc: "Schema normalisation" },
  { label: "Delta Engine", icon: ArrowRight, desc: "Change detection" },
  { label: "MDM", icon: Shield, desc: "Master entity resolution" },
  { label: "Policy Layer", icon: Shield, desc: "Rule-based filtering" },
  { label: "Export / API", icon: Plug, desc: "Delivery & alerting" },
];

const features = [
  { title: "Raw + Cleansed Fields", desc: "Preserve original data alongside standardised output for full auditability" },
  { title: "Delta Updates", desc: "Track additions, modifications, and removals across every source revision" },
  { title: "Source Lineage", desc: "Full provenance chain from raw source to delivered record" },
  { title: "Auditability", desc: "Every transformation logged with timestamps and version identifiers" },
  { title: "MDM Entity Consolidation", desc: "Merge duplicate entities across sources into master records" },
  { title: "Policy-Based Selection", desc: "Configurable list inclusion/exclusion based on regulatory requirements" },
];

const schemaFields = [
  { field: "master_entity_id", type: "UUID", desc: "Unique consolidated entity identifier" },
  { field: "primary_name", type: "VARCHAR", desc: "Primary display name" },
  { field: "aliases", type: "JSONB", desc: "Array of known aliases and alternative spellings" },
  { field: "date_of_birth", type: "DATE", desc: "Date of birth or incorporation" },
  { field: "country", type: "VARCHAR", desc: "Primary jurisdiction" },
  { field: "identifiers", type: "JSONB", desc: "Passport, tax ID, registration numbers" },
  { field: "sanction_status", type: "ENUM", desc: "active | delisted | under_review" },
  { field: "source_names", type: "JSONB", desc: "Contributing source list names" },
  { field: "listed_date", type: "TIMESTAMP", desc: "Date first listed on any source" },
  { field: "updated_date", type: "TIMESTAMP", desc: "Last modification timestamp" },
  { field: "active_flag", type: "BOOLEAN", desc: "Current active/inactive status" },
];

const DataArchitecture = () => (
  <DashboardLayout>
    <div className="p-6 space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-2xl font-bold tracking-tight mb-1">Sanctions Data Architecture</h1>
        <p className="text-sm text-muted-foreground">End-to-end pipeline from raw sources to policy-driven delivery</p>
      </motion.div>

      {/* Pipeline */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        className="rounded-xl bg-card shadow-sm p-6"
      >
        <h3 className="text-sm font-semibold mb-5">Processing Pipeline</h3>
        <div className="flex items-center gap-1 overflow-x-auto pb-2">
          {pipelineSteps.map((step, i) => (
            <div key={step.label} className="flex items-center gap-1">
              <div className="flex flex-col items-center gap-1.5 min-w-[80px]">
                <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                  <step.icon className="h-4 w-4" />
                </div>
                <span className="text-[10px] font-medium text-center">{step.label}</span>
                <span className="text-[9px] text-muted-foreground text-center">{step.desc}</span>
              </div>
              {i < pipelineSteps.length - 1 && <ArrowRight className="h-3 w-3 text-muted-foreground flex-shrink-0 mx-1" />}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Feature Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((f, i) => (
          <motion.div key={f.title} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 + i * 0.05 }}
            className="rounded-xl bg-card shadow-sm p-5"
          >
            <CheckCircle2 className="h-4 w-4 text-success mb-2" />
            <div className="text-sm font-semibold mb-1">{f.title}</div>
            <div className="text-xs text-muted-foreground">{f.desc}</div>
          </motion.div>
        ))}
      </div>

      {/* Schema Table */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
        className="rounded-xl bg-card shadow-sm overflow-hidden"
      >
        <div className="px-5 py-3.5 border-b">
          <h3 className="text-sm font-semibold">Entity Schema — master_entities</h3>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-xs">Field</TableHead>
              <TableHead className="text-xs">Type</TableHead>
              <TableHead className="text-xs">Description</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {schemaFields.map(f => (
              <TableRow key={f.field}>
                <TableCell className="font-mono text-xs text-primary">{f.field}</TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground">{f.type}</TableCell>
                <TableCell className="text-xs">{f.desc}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </motion.div>
    </div>
  </DashboardLayout>
);

export default DataArchitecture;
