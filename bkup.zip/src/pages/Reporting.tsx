import { motion } from "framer-motion";
import { FileText, Send, Download, TrendingUp, TrendingDown, Users, AlertTriangle, Clock, CheckCircle2, BarChart3 } from "lucide-react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const monthlyAlerts = [
  { month: "Oct", alerts: 189 }, { month: "Nov", alerts: 204 }, { month: "Dec", alerts: 178 },
  { month: "Jan", alerts: 221 }, { month: "Feb", alerts: 195 }, { month: "Mar", alerts: 167 },
];
const fpReduction = [
  { month: "Oct", rate: 42 }, { month: "Nov", rate: 38 }, { month: "Dec", rate: 31 },
  { month: "Jan", rate: 25 }, { month: "Feb", rate: 19 }, { month: "Mar", rate: 14 },
];
const buAlerts = [
  { name: "Retail Banking", value: 45, color: "hsl(221 83% 53%)" },
  { name: "Corporate Banking", value: 28, color: "hsl(263 70% 58%)" },
  { name: "Wealth Management", value: 18, color: "hsl(38 92% 50%)" },
  { name: "Trade Finance", value: 9, color: "hsl(142 71% 45%)" },
];

const execKpis = [
  { label: "Portfolio Monitored", value: "12,847", icon: Users, trend: "+12%" },
  { label: "False Positive Reduction", value: "67%", icon: TrendingDown, trend: "↓ vs baseline" },
  { label: "Time Saved per Analyst", value: "4.2h/day", icon: Clock, trend: "+23%" },
  { label: "High-Risk Cases Open", value: "31", icon: AlertTriangle, trend: "-8 this week" },
  { label: "Confirmed Escalations", value: "12", icon: CheckCircle2, trend: "+3 this month" },
  { label: "SLA Compliance", value: "98.4%", icon: BarChart3, trend: "Above target" },
];

const Reporting = () => (
  <DashboardLayout>
    <div className="p-6 space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight mb-1">Executive Reporting</h1>
          <p className="text-sm text-muted-foreground">Board-level compliance metrics and performance analytics</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-1" /> Export PDF</Button>
          <Button variant="outline" size="sm"><FileText className="h-4 w-4 mr-1" /> Board Pack</Button>
          <Button size="sm"><Send className="h-4 w-4 mr-1" /> Weekly Digest</Button>
        </div>
      </motion.div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {execKpis.map((kpi, i) => (
          <motion.div key={kpi.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
            className="rounded-xl bg-card shadow-sm p-4"
          >
            <kpi.icon className="h-4 w-4 text-muted-foreground mb-2" />
            <div className="text-xl font-bold font-mono">{kpi.value}</div>
            <div className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</div>
            <div className="text-[10px] text-success mt-1">{kpi.trend}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}
          className="rounded-xl bg-card shadow-sm p-5"
        >
          <h3 className="text-sm font-semibold mb-4">Monthly Alert Trend</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyAlerts}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(220 10% 46%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220 10% 46%)" />
              <Tooltip />
              <Bar dataKey="alerts" fill="hsl(221 83% 53%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.35 }}
          className="rounded-xl bg-card shadow-sm p-5"
        >
          <h3 className="text-sm font-semibold mb-4">False Positive Rate (%)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={fpReduction}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(220 10% 46%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220 10% 46%)" />
              <Tooltip />
              <Line type="monotone" dataKey="rate" stroke="hsl(142 71% 45%)" strokeWidth={2} dot={{ fill: "hsl(142 71% 45%)" }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
        className="rounded-xl bg-card shadow-sm p-5"
      >
        <h3 className="text-sm font-semibold mb-4">Alerts by Business Unit</h3>
        <div className="flex items-center gap-8">
          <ResponsiveContainer width={200} height={200}>
            <PieChart>
              <Pie data={buAlerts} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3}>
                {buAlerts.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2">
            {buAlerts.map(bu => (
              <div key={bu.name} className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-sm" style={{ background: bu.color }} />
                <span className="text-sm">{bu.name}</span>
                <span className="text-sm font-mono font-bold ml-auto">{bu.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  </DashboardLayout>
);

export default Reporting;
