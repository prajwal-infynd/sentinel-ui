import { motion } from "framer-motion";
import { AlertTriangle, User, Calendar, ExternalLink, UserPlus, CheckCircle2, ArrowUpRight, FileText, Clock, Brain, Shield } from "lucide-react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";

const Investigation = () => (
  <DashboardLayout>
    <div className="p-6 space-y-6">
      {/* Case Header */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-xl bg-card shadow-sm p-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Badge className="bg-destructive/10 text-destructive border-0">CRITICAL</Badge>
              <span className="text-xs font-mono text-muted-foreground">ALT-4891</span>
            </div>
            <h1 className="text-xl font-bold tracking-tight mb-1">Adverse media hit — suspected fraud exposure</h1>
            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1"><User className="h-3.5 w-3.5" /> John Doe</span>
              <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> 2024-03-15 14:23 UTC</span>
              <span className="flex items-center gap-1"><ExternalLink className="h-3.5 w-3.5" /> Financial Times</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-center px-4">
              <div className="text-2xl font-bold font-mono text-destructive">94%</div>
              <div className="text-[10px] text-muted-foreground">Confidence</div>
            </div>
            <Button variant="outline" size="sm"><UserPlus className="h-4 w-4 mr-1" /> Assign</Button>
            <Button size="sm"><CheckCircle2 className="h-4 w-4 mr-1" /> Review</Button>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <Tabs defaultValue="summary">
        <TabsList className="bg-card border">
          <TabsTrigger value="summary" className="text-xs">Summary</TabsTrigger>
          <TabsTrigger value="evidence" className="text-xs">Source Evidence</TabsTrigger>
          <TabsTrigger value="entity" className="text-xs">Entity Profile</TabsTrigger>
          <TabsTrigger value="timeline" className="text-xs">Timeline</TabsTrigger>
          <TabsTrigger value="reasoning" className="text-xs">AI Reasoning</TabsTrigger>
          <TabsTrigger value="audit" className="text-xs">Audit Trail</TabsTrigger>
        </TabsList>

        <TabsContent value="summary">
          <div className="grid md:grid-cols-2 gap-6 mt-4">
            <div className="rounded-xl bg-card shadow-sm p-6 space-y-4">
              <h3 className="font-semibold flex items-center gap-2"><Brain className="h-4 w-4 text-accent" /> AI-Generated Summary</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                A Financial Times investigative report published on 15 March 2024 identifies <span className="font-medium text-foreground">John Doe</span> as a person
                of interest in a multi-jurisdictional fraud investigation. The article cites sources within the UK Serious Fraud Office and references
                suspicious transaction patterns involving offshore shell companies in the British Virgin Islands.
              </p>
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Matched Fields</h4>
                <div className="flex flex-wrap gap-2">
                  {["Full name match", "DOB confirmed", "UK jurisdiction", "Known associate"].map(f => (
                    <Badge key={f} variant="outline" className="text-xs">{f}</Badge>
                  ))}
                </div>
              </div>
            </div>
            <div className="rounded-xl bg-card shadow-sm p-6 space-y-4">
              <h3 className="font-semibold flex items-center gap-2"><Shield className="h-4 w-4 text-primary" /> Suggested Actions</h3>
              <div className="space-y-3">
                {[
                  { action: "Escalate to Senior Analyst", priority: "Recommended", color: "bg-warning/10 text-warning" },
                  { action: "Request enhanced due diligence", priority: "Required", color: "bg-destructive/10 text-destructive" },
                  { action: "File SAR consideration", priority: "Under Review", color: "bg-primary/10 text-primary" },
                  { action: "Notify relationship manager", priority: "Optional", color: "bg-muted text-muted-foreground" },
                ].map(a => (
                  <div key={a.action} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <span className="text-sm">{a.action}</span>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${a.color}`}>{a.priority}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="evidence">
          <div className="grid md:grid-cols-2 gap-6 mt-4">
            <div className="rounded-xl bg-card shadow-sm p-6">
              <h3 className="font-semibold mb-3 flex items-center gap-2"><FileText className="h-4 w-4" /> Source Article</h3>
              <div className="text-xs text-muted-foreground mb-2">Financial Times • 15 March 2024</div>
              <div className="prose prose-sm text-sm text-muted-foreground max-w-none space-y-3">
                <p>The UK Serious Fraud Office has identified <mark className="bg-warning/20 text-foreground px-0.5 rounded">John Doe</mark> as a person of interest in connection with a complex fraud scheme involving multiple offshore entities...</p>
                <p>Investigators have traced suspicious transactions totalling approximately £4.2 million through shell companies registered in the <mark className="bg-warning/20 text-foreground px-0.5 rounded">British Virgin Islands</mark>.</p>
              </div>
            </div>
            <div className="rounded-xl bg-card shadow-sm p-6">
              <h3 className="font-semibold mb-3">Sanctions Match</h3>
              <div className="space-y-3 text-sm">
                <div className="p-3 rounded-lg bg-muted/50">
                  <div className="text-xs text-muted-foreground mb-1">Source: OFAC SDN List</div>
                  <div className="font-medium">No direct match found</div>
                </div>
                <div className="p-3 rounded-lg bg-warning/5 border border-warning/20">
                  <div className="text-xs text-muted-foreground mb-1">Source: EU Consolidated List</div>
                  <div className="font-medium">Fuzzy match — 72% similarity</div>
                  <div className="text-xs text-muted-foreground mt-1">Entity: "Johan Doe" — ref. EU-2024-1847</div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="entity">
          <div className="grid md:grid-cols-3 gap-6 mt-4">
            <div className="md:col-span-2 rounded-xl bg-card shadow-sm p-6">
              <h3 className="font-semibold mb-4">Master Entity Profile</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                {[
                  ["Full Name", "John Michael Doe"],
                  ["Aliases", "J. Doe, Johan Doe, JMD"],
                  ["Date of Birth", "22 March 1985"],
                  ["Nationality", "British"],
                  ["Identifiers", "Passport: GB-8842991"],
                  ["Linked Jurisdictions", "UK, BVI, UAE, Switzerland"],
                ].map(([label, value]) => (
                  <div key={label}>
                    <div className="text-xs text-muted-foreground mb-0.5">{label}</div>
                    <div className="text-sm font-medium">{value}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl bg-card shadow-sm p-6">
              <h3 className="font-semibold mb-4">Risk Indicators</h3>
              <div className="space-y-3">
                {[
                  { label: "Sanctions Lists", count: 0, color: "text-success" },
                  { label: "PEP Associations", count: 1, color: "text-warning" },
                  { label: "Adverse Media", count: 3, color: "text-destructive" },
                  { label: "Watchlist Memberships", count: 2, color: "text-warning" },
                ].map(r => (
                  <div key={r.label} className="flex items-center justify-between">
                    <span className="text-sm">{r.label}</span>
                    <span className={`font-mono font-bold ${r.color}`}>{r.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="timeline">
          <div className="rounded-xl bg-card shadow-sm p-6 mt-4">
            <h3 className="font-semibold mb-4">Entity Event Timeline</h3>
            <div className="space-y-4">
              {[
                { date: "15 Mar 2024, 14:23", event: "Adverse media hit detected — Financial Times fraud article", severity: "critical" },
                { date: "12 Mar 2024, 09:15", event: "EU sanctions list update — fuzzy match identified", severity: "high" },
                { date: "28 Feb 2024, 11:42", event: "PEP association discovered — linked political figure", severity: "high" },
                { date: "15 Feb 2024, 16:30", event: "Routine screening completed — no new signals", severity: "low" },
                { date: "01 Feb 2024, 08:00", event: "Entity onboarded for continuous monitoring", severity: "info" },
              ].map((e, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className={`h-2.5 w-2.5 rounded-full mt-1.5 ${
                      e.severity === "critical" ? "bg-destructive" : e.severity === "high" ? "bg-warning" :
                      e.severity === "low" ? "bg-success" : "bg-muted-foreground"
                    }`} />
                    {i < 4 && <div className="w-px flex-1 bg-border mt-1" />}
                  </div>
                  <div className="pb-4">
                    <div className="text-xs font-mono text-muted-foreground">{e.date}</div>
                    <div className="text-sm mt-0.5">{e.event}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="reasoning">
          <div className="rounded-xl bg-card shadow-sm p-6 mt-4 space-y-5">
            <h3 className="font-semibold flex items-center gap-2"><Brain className="h-4 w-4 text-accent" /> AI Reasoning Chain</h3>
            {[
              { step: "Sources Checked", detail: "OFAC SDN, EU Consolidated, UN Sanctions, UK HMT, 2,847 media sources" },
              { step: "Entities Extracted", detail: "3 named entities from FT article matched against portfolio: John Doe (94%), BVI Holdings (67%), J. Doe Associates (45%)" },
              { step: "Matching Confidence", detail: "Primary entity: 94% confidence based on full name, DOB, and jurisdiction alignment" },
              { step: "Risk Signals Detected", detail: "Fraud investigation, SFO involvement, offshore transaction patterns, shell company structures" },
              { step: "Severity Rationale", detail: "Classified as CRITICAL due to: active law enforcement investigation, high confidence match, and potential SAR obligation" },
            ].map((s, i) => (
              <div key={i} className="flex gap-4 items-start">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-accent/10 text-accent text-xs font-bold shrink-0">{i + 1}</div>
                <div>
                  <div className="text-sm font-medium">{s.step}</div>
                  <div className="text-sm text-muted-foreground mt-0.5">{s.detail}</div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="audit">
          <div className="rounded-xl bg-card shadow-sm p-6 mt-4">
            <h3 className="font-semibold mb-4">Audit Trail</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Timestamp</TableHead>
                  <TableHead className="text-xs">Component</TableHead>
                  <TableHead className="text-xs">Version</TableHead>
                  <TableHead className="text-xs">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[
                  { ts: "2024-03-15 14:23:41", comp: "Media Crawler", ver: "v3.2.1", action: "Article ingested from FT RSS feed" },
                  { ts: "2024-03-15 14:23:44", comp: "NER Engine", ver: "v2.1.0", action: "Named entity extraction completed" },
                  { ts: "2024-03-15 14:23:47", comp: "Matching Engine", ver: "v4.0.3", action: "Entity resolved against portfolio" },
                  { ts: "2024-03-15 14:23:49", comp: "Risk Scorer", ver: "v1.8.2", action: "Risk score calculated: 87 → 94" },
                  { ts: "2024-03-15 14:23:51", comp: "Alert Engine", ver: "v2.5.0", action: "Alert ALT-4891 generated" },
                  { ts: "2024-03-15 14:24:02", comp: "Case Generator", ver: "v1.3.1", action: "Case summary auto-generated" },
                ].map((r, i) => (
                  <TableRow key={i}>
                    <TableCell className="font-mono text-xs">{r.ts}</TableCell>
                    <TableCell className="text-xs">{r.comp}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{r.ver}</TableCell>
                    <TableCell className="text-xs">{r.action}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  </DashboardLayout>
);

export default Investigation;
