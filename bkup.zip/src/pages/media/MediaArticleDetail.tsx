import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, ExternalLink, FileText, Globe, Shield, User, Building, AlertTriangle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DashboardLayout } from "@/components/DashboardLayout";
import { fetchMediaArticleDetail } from "@/lib/media-agent-data";

const severityColor = (severity: string) =>
  severity === "critical"
    ? "bg-destructive/10 text-destructive border-destructive/20"
    : severity === "high"
      ? "bg-warning/10 text-warning border-warning/20"
      : severity === "medium"
        ? "bg-primary/10 text-primary border-primary/20"
        : "bg-muted text-muted-foreground border-border";

export default function MediaArticleDetail() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const { data: article } = useQuery({ queryKey: ["media-article", id], queryFn: () => fetchMediaArticleDetail(id), enabled: Boolean(id) });

  if (!article) {
    return (
      <DashboardLayout>
        <div className="p-6">
          <Button variant="ghost" size="sm" onClick={() => navigate("/media")} className="mb-3 -ml-2 text-muted-foreground"><ArrowLeft className="mr-1 h-3.5 w-3.5" /> Back to Media Stream</Button>
          <div className="text-sm text-muted-foreground">Loading article intelligence…</div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <Button variant="ghost" size="sm" onClick={() => navigate("/media")} className="mb-3 -ml-2 text-muted-foreground"><ArrowLeft className="mr-1 h-3.5 w-3.5" /> Back to Media Stream</Button>
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold tracking-tight leading-tight">{article.headline}</h1>
              <div className="mt-2 flex items-center gap-3 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Globe className="h-3.5 w-3.5" />{article.source}</span>
                <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{article.timestamp}</span>
                <span>·</span>
                <span>{article.language}</span>
                <span>·</span>
                <span>Credibility: <span className="font-mono font-bold">{article.credibilityScore}</span></span>
              </div>
            </div>
            <Badge className={`text-xs px-2 py-0.5 uppercase ${severityColor(article.severity)}`}>{article.severity}</Badge>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.1 }} className="lg:col-span-3">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><FileText className="h-3.5 w-3.5 text-primary" />Article Content</CardTitle></CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none text-sm leading-relaxed">
                  {article.content.split(new RegExp(`(${article.entities.join("|")})`, "gi")).map((part, index) => {
                    const isEntity = article.entities.some((entity) => entity.toLowerCase() === part.toLowerCase());
                    return isEntity ? <mark key={index} className="rounded bg-primary/15 px-0.5 font-medium text-primary">{part}</mark> : <span key={index}>{part}</span>;
                  })}
                </div>
                <div className="mt-4 flex items-center gap-2 border-t pt-4">
                  <Button variant="outline" size="sm" className="gap-1 text-xs"><ExternalLink className="h-3 w-3" /> View Source</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.2 }} className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Shield className="h-3.5 w-3.5 text-accent" />AI Analysis</CardTitle></CardHeader>
              <CardContent>
                <Tabs defaultValue="entities" className="space-y-4">
                  <TabsList className="grid h-8 grid-cols-4">
                    <TabsTrigger value="entities" className="text-[10px]">Entities</TabsTrigger>
                    <TabsTrigger value="risk" className="text-[10px]">Risk</TabsTrigger>
                    <TabsTrigger value="summary" className="text-[10px]">Summary</TabsTrigger>
                    <TabsTrigger value="trace" className="text-[10px]">Trace</TabsTrigger>
                  </TabsList>

                  <TabsContent value="entities" className="space-y-3">
                    <div className="text-[10px] font-semibold uppercase text-muted-foreground">Extracted Entities</div>
                    {article.entities.map((entity) => (
                      <div key={entity} className="flex items-center justify-between rounded-lg border p-2.5">
                        <div className="flex items-center gap-2">{entity.includes(" ") ? <User className="h-3.5 w-3.5 text-accent" /> : <Building className="h-3.5 w-3.5 text-primary" />}<span className="text-xs font-medium">{entity}</span></div>
                        {entity === article.matchedEntity && <Badge className="border-success/20 bg-success/10 text-[9px] text-success">Matched</Badge>}
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="risk" className="space-y-3">
                    <div className="text-[10px] font-semibold uppercase text-muted-foreground">Detected Risk Signals</div>
                    {article.riskTags.map((tag) => (
                      <div key={tag} className="flex items-center justify-between rounded-lg border p-2.5">
                        <div className="flex items-center gap-2"><AlertTriangle className="h-3.5 w-3.5 text-warning" /><span className="text-xs font-medium capitalize">{tag}</span></div>
                        <Badge variant="outline" className="text-[9px] font-mono">{article.severity}</Badge>
                      </div>
                    ))}
                    <div className="rounded-lg bg-muted/50 p-3 text-[11px] text-muted-foreground">Risk score <span className="font-mono font-bold text-foreground">{article.riskScore}</span> with <span className="font-mono font-bold text-foreground">{article.matchConfidence}%</span> match confidence.</div>
                  </TabsContent>

                  <TabsContent value="summary" className="space-y-3">
                    <div className="text-[10px] font-semibold uppercase text-muted-foreground">AI Summary</div>
                    <div className="rounded-lg border border-accent/10 bg-accent/5 p-3"><p className="text-xs leading-relaxed">{article.summary}</p></div>
                  </TabsContent>

                  <TabsContent value="trace" className="space-y-2">
                    <div className="text-[10px] font-semibold uppercase text-muted-foreground">Evidence & Traceability</div>
                    {article.trace.map((item) => (
                      <div key={item.label} className="flex items-center justify-between border-b border-border/50 py-1.5 last:border-0"><span className="text-[11px] text-muted-foreground">{item.label}</span><span className="text-[11px] font-mono">{item.value}</span></div>
                    ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </DashboardLayout>
  );
}
