import { motion } from "framer-motion";
import { ArrowRight, Search, TrendingUp, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DashboardLayout } from "@/components/DashboardLayout";
import { fetchMediaAlerts } from "@/lib/media-agent-data";

const severityColor = (severity: string) =>
  severity === "critical"
    ? "bg-destructive/10 text-destructive border-destructive/20"
    : severity === "high"
      ? "bg-warning/10 text-warning border-warning/20"
      : "bg-primary/10 text-primary border-primary/20";

export default function MediaAlerts() {
  const { data: alerts = [] } = useQuery({ queryKey: ["media-live-alerts"], queryFn: () => fetchMediaAlerts(12), refetchInterval: 10000 });

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <h1 className="text-2xl font-bold tracking-tight">Media Alert Generation</h1>
          <p className="mt-1 text-sm text-muted-foreground">Live alerts created by the autonomous adverse media pipeline</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center justify-center gap-2">
                {["Article Detected", "Entity Extraction", "Portfolio Match", "Risk Scoring", "Alert Created"].map((step, index) => (
                  <div key={step} className="flex items-center gap-2">
                    <div className={`rounded-lg border px-3 py-2 text-xs font-medium ${index === 4 ? "border-destructive/20 bg-destructive/10 text-destructive" : "border-border bg-muted/50"}`}>
                      {step}
                    </div>
                    {index < 4 && <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/40" />}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="space-y-4">
          {alerts.map((alert, index) => (
            <motion.div key={alert.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: 0.15 + index * 0.06 }}>
              <Card className="transition-[box-shadow] hover:shadow-lg">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="mb-2 flex items-center gap-2">
                        <Badge className={`text-[10px] uppercase ${severityColor(alert.severity)}`}>{alert.severity}</Badge>
                        <span className="text-[10px] text-muted-foreground">{new Date(alert.generatedAt).toLocaleString()}</span>
                      </div>
                      <h3 className="mb-1 text-sm font-semibold">{alert.title}</h3>
                      <p className="mb-3 text-xs text-muted-foreground">{alert.summary}</p>

                      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                        <div className="rounded-lg bg-muted/50 p-2.5">
                          <div className="text-[9px] text-muted-foreground">Entity</div>
                          <div className="text-xs font-medium">{alert.entityName}</div>
                        </div>
                        <div className="rounded-lg bg-muted/50 p-2.5">
                          <div className="text-[9px] text-muted-foreground">Article</div>
                          <div className="truncate text-xs font-medium">{alert.articleHeadline}</div>
                        </div>
                        <div className="rounded-lg bg-muted/50 p-2.5">
                          <div className="text-[9px] text-muted-foreground">Confidence</div>
                          <div className="text-xs font-mono font-bold">{alert.confidenceScore}%</div>
                        </div>
                        <div className="rounded-lg bg-muted/50 p-2.5">
                          <div className="text-[9px] text-muted-foreground">Status</div>
                          <div className="text-xs font-medium capitalize">{alert.status.replace(/_/g, " ")}</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center gap-2 border-t pt-3">
                    <Button size="sm" className="h-7 gap-1 text-xs"><Search className="h-3 w-3" /> Open Case</Button>
                    <Button size="sm" variant="outline" className="h-7 gap-1 text-xs"><X className="h-3 w-3" /> Dismiss</Button>
                    <Button size="sm" variant="outline" className="h-7 gap-1 text-xs text-destructive border-destructive/30"><TrendingUp className="h-3 w-3" /> Escalate</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
