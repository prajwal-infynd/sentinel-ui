import { motion } from "framer-motion";
import { Bot, CheckCircle2, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Progress } from "@/components/ui/progress";
import { fetchAgentOverview } from "@/lib/media-agent-data";

const pipelineSteps = ["Sources", "Extraction", "Matching", "Scoring", "Policy Rules", "Alert", "Case Generation"];

const AIAgents = () => {
  const { data: agents = [] } = useQuery({ queryKey: ["agent-overview"], queryFn: fetchAgentOverview, refetchInterval: 10000 });

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <h1 className="mb-1 text-2xl font-bold tracking-tight">AI Agent Orchestration</h1>
          <p className="text-sm text-muted-foreground">Live run history, throughput, and confidence across the monitoring agent chain</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-xl bg-card p-6 shadow-sm">
          <h3 className="mb-5 text-sm font-semibold">Orchestration Pipeline</h3>
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-2">
            {pipelineSteps.map((step, index) => (
              <div key={step} className="flex items-center gap-2">
                <div className="flex flex-col items-center gap-1.5">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-lg text-xs font-bold ${index < 4 ? "bg-primary/10 text-primary" : "bg-success/10 text-success"}`}>
                    {index + 1}
                  </div>
                  <span className="whitespace-nowrap text-[10px] text-muted-foreground">{step}</span>
                </div>
                {index < pipelineSteps.length - 1 && <div className="h-px w-8 flex-shrink-0 bg-border" />}
              </div>
            ))}
          </div>
        </motion.div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {agents.map((agent, index) => (
            <motion.div key={agent.name} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + index * 0.06 }} className="rounded-xl bg-card p-5 shadow-sm">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-accent">
                    <Bot className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold">{agent.name}</div>
                    <div className="flex items-center gap-1">
                      <div className={`h-1.5 w-1.5 rounded-full ${agent.status === "running" ? "bg-success animate-pulse" : agent.status === "completed" ? "bg-primary" : "bg-muted-foreground"}`} />
                      <span className="text-[10px] capitalize text-muted-foreground">{agent.status}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mb-4 grid grid-cols-2 gap-3">
                <div>
                  <div className="text-lg font-bold font-mono">{agent.processed.toLocaleString()}</div>
                  <div className="text-[10px] text-muted-foreground">Items processed</div>
                </div>
                <div>
                  <div className="text-lg font-bold font-mono">{agent.signals.toLocaleString()}</div>
                  <div className="text-[10px] text-muted-foreground">Signals generated</div>
                </div>
              </div>

              <div className="mb-3 text-xs text-muted-foreground truncate"><Clock className="mr-1 inline h-3 w-3" />{agent.lastAction}</div>
              <div className="mb-2 flex items-center gap-2 text-[10px] text-muted-foreground"><CheckCircle2 className="h-3 w-3 text-success" />Uptime {agent.uptime}</div>
              <div className="flex items-center gap-2">
                <Progress value={agent.accuracy} className="h-1.5" />
                <span className="text-xs font-mono text-muted-foreground">{agent.accuracy}%</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AIAgents;
