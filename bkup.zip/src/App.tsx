import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index";
import DemoEntry from "./pages/DemoEntry";
import PortfolioOnboarding from "./pages/PortfolioOnboarding";
import Dashboard from "./pages/Dashboard";
import LiveAlerts from "./pages/LiveAlerts";
import Investigation from "./pages/Investigation";
import AIAgents from "./pages/AIAgents";
import DataArchitecture from "./pages/DataArchitecture";
import PolicyConfig from "./pages/PolicyConfig";
import Reporting from "./pages/Reporting";
import DemoClosing from "./pages/DemoClosing";
import NotFound from "./pages/NotFound";
import MediaDashboard from "./pages/media/MediaDashboard";
import MediaSources from "./pages/media/MediaSources";
import MediaPipeline from "./pages/media/MediaPipeline";
import MediaArticleDetail from "./pages/media/MediaArticleDetail";
import MediaEntityView from "./pages/media/MediaEntityView";
import MediaSignals from "./pages/media/MediaSignals";
import MediaConfig from "./pages/media/MediaConfig";
import MediaAlerts from "./pages/media/MediaAlerts";
import MediaWorkspace from "./pages/media/MediaWorkspace";
import MediaExplainability from "./pages/media/MediaExplainability";
import MediaAutomation from "./pages/media/MediaAutomation";
import { ProtectedRoute } from "@/lib/auth";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/demo" element={<ProtectedRoute><DemoEntry /></ProtectedRoute>} />
          <Route path="/portfolio" element={<ProtectedRoute><PortfolioOnboarding /></ProtectedRoute>} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/alerts" element={<ProtectedRoute><LiveAlerts /></ProtectedRoute>} />
          <Route path="/investigations" element={<ProtectedRoute><Investigation /></ProtectedRoute>} />
          <Route path="/agents" element={<ProtectedRoute><AIAgents /></ProtectedRoute>} />
          <Route path="/architecture" element={<ProtectedRoute><DataArchitecture /></ProtectedRoute>} />
          <Route path="/policy" element={<ProtectedRoute><PolicyConfig /></ProtectedRoute>} />
          <Route path="/reporting" element={<ProtectedRoute><Reporting /></ProtectedRoute>} />
          <Route path="/closing" element={<ProtectedRoute><DemoClosing /></ProtectedRoute>} />
          <Route path="/media" element={<ProtectedRoute><MediaDashboard /></ProtectedRoute>} />
          <Route path="/media/sources" element={<ProtectedRoute><MediaSources /></ProtectedRoute>} />
          <Route path="/media/pipeline" element={<ProtectedRoute><MediaPipeline /></ProtectedRoute>} />
          <Route path="/media/article/:id" element={<ProtectedRoute><MediaArticleDetail /></ProtectedRoute>} />
          <Route path="/media/entity" element={<ProtectedRoute><MediaEntityView /></ProtectedRoute>} />
          <Route path="/media/signals" element={<ProtectedRoute><MediaSignals /></ProtectedRoute>} />
          <Route path="/media/config" element={<ProtectedRoute><MediaConfig /></ProtectedRoute>} />
          <Route path="/media/alerts" element={<ProtectedRoute><MediaAlerts /></ProtectedRoute>} />
          <Route path="/media/workspace" element={<ProtectedRoute><MediaWorkspace /></ProtectedRoute>} />
          <Route path="/media/explainability" element={<ProtectedRoute><MediaExplainability /></ProtectedRoute>} />
          <Route path="/media/automation" element={<ProtectedRoute><MediaAutomation /></ProtectedRoute>} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
