export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      agent_runs: {
        Row: {
          agent_name: string
          average_confidence: number | null
          completed_at: string | null
          created_at: string
          details: Json
          id: string
          input_count: number
          organization_id: string
          output_count: number
          stage: string | null
          started_at: string
          status: Database["public"]["Enums"]["agent_status"]
          updated_at: string
        }
        Insert: {
          agent_name: string
          average_confidence?: number | null
          completed_at?: string | null
          created_at?: string
          details?: Json
          id?: string
          input_count?: number
          organization_id: string
          output_count?: number
          stage?: string | null
          started_at?: string
          status?: Database["public"]["Enums"]["agent_status"]
          updated_at?: string
        }
        Update: {
          agent_name?: string
          average_confidence?: number | null
          completed_at?: string | null
          created_at?: string
          details?: Json
          id?: string
          input_count?: number
          organization_id?: string
          output_count?: number
          stage?: string | null
          started_at?: string
          status?: Database["public"]["Enums"]["agent_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_runs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      alerts: {
        Row: {
          acknowledged_at: string | null
          article_id: string | null
          assigned_to: string | null
          confidence_score: number
          created_at: string
          entity_id: string | null
          generated_at: string
          id: string
          organization_id: string
          recommendation: string | null
          resolved_at: string | null
          severity: Database["public"]["Enums"]["risk_severity"]
          signal_id: string | null
          status: Database["public"]["Enums"]["alert_status"]
          summary: string | null
          title: string
          updated_at: string
        }
        Insert: {
          acknowledged_at?: string | null
          article_id?: string | null
          assigned_to?: string | null
          confidence_score?: number
          created_at?: string
          entity_id?: string | null
          generated_at?: string
          id?: string
          organization_id: string
          recommendation?: string | null
          resolved_at?: string | null
          severity: Database["public"]["Enums"]["risk_severity"]
          signal_id?: string | null
          status?: Database["public"]["Enums"]["alert_status"]
          summary?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          acknowledged_at?: string | null
          article_id?: string | null
          assigned_to?: string | null
          confidence_score?: number
          created_at?: string
          entity_id?: string | null
          generated_at?: string
          id?: string
          organization_id?: string
          recommendation?: string | null
          resolved_at?: string | null
          severity?: Database["public"]["Enums"]["risk_severity"]
          signal_id?: string | null
          status?: Database["public"]["Enums"]["alert_status"]
          summary?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "alerts_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "media_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alerts_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "monitored_entities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alerts_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alerts_signal_id_fkey"
            columns: ["signal_id"]
            isOneToOne: false
            referencedRelation: "risk_signals"
            referencedColumns: ["id"]
          },
        ]
      }
      analyst_notes: {
        Row: {
          alert_id: string | null
          article_id: string | null
          author_user_id: string
          body: string
          case_id: string | null
          created_at: string
          id: string
          organization_id: string
          updated_at: string
        }
        Insert: {
          alert_id?: string | null
          article_id?: string | null
          author_user_id: string
          body: string
          case_id?: string | null
          created_at?: string
          id?: string
          organization_id: string
          updated_at?: string
        }
        Update: {
          alert_id?: string | null
          article_id?: string | null
          author_user_id?: string
          body?: string
          case_id?: string | null
          created_at?: string
          id?: string
          organization_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "analyst_notes_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "alerts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analyst_notes_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "media_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analyst_notes_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "analyst_notes_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      article_entity_matches: {
        Row: {
          article_id: string
          context_snippet: string | null
          created_at: string
          entity_id: string | null
          extracted_name: string
          extraction_confidence: number
          id: string
          match_confidence: number | null
          risk_tags: string[]
        }
        Insert: {
          article_id: string
          context_snippet?: string | null
          created_at?: string
          entity_id?: string | null
          extracted_name: string
          extraction_confidence?: number
          id?: string
          match_confidence?: number | null
          risk_tags?: string[]
        }
        Update: {
          article_id?: string
          context_snippet?: string | null
          created_at?: string
          entity_id?: string | null
          extracted_name?: string
          extraction_confidence?: number
          id?: string
          match_confidence?: number | null
          risk_tags?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "article_entity_matches_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "media_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "article_entity_matches_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "monitored_entities"
            referencedColumns: ["id"]
          },
        ]
      }
      case_alerts: {
        Row: {
          alert_id: string
          case_id: string
          created_at: string
          id: string
        }
        Insert: {
          alert_id: string
          case_id: string
          created_at?: string
          id?: string
        }
        Update: {
          alert_id?: string
          case_id?: string
          created_at?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "case_alerts_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "alerts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "case_alerts_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "cases"
            referencedColumns: ["id"]
          },
        ]
      }
      cases: {
        Row: {
          assignee_user_id: string | null
          case_number: string
          closed_at: string | null
          created_at: string
          entity_id: string | null
          id: string
          opened_at: string
          organization_id: string
          primary_alert_id: string | null
          resolution_notes: string | null
          severity: Database["public"]["Enums"]["risk_severity"]
          status: Database["public"]["Enums"]["case_status"]
          summary: string | null
          title: string
          updated_at: string
        }
        Insert: {
          assignee_user_id?: string | null
          case_number?: string
          closed_at?: string | null
          created_at?: string
          entity_id?: string | null
          id?: string
          opened_at?: string
          organization_id: string
          primary_alert_id?: string | null
          resolution_notes?: string | null
          severity?: Database["public"]["Enums"]["risk_severity"]
          status?: Database["public"]["Enums"]["case_status"]
          summary?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          assignee_user_id?: string | null
          case_number?: string
          closed_at?: string | null
          created_at?: string
          entity_id?: string | null
          id?: string
          opened_at?: string
          organization_id?: string
          primary_alert_id?: string | null
          resolution_notes?: string | null
          severity?: Database["public"]["Enums"]["risk_severity"]
          status?: Database["public"]["Enums"]["case_status"]
          summary?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cases_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "monitored_entities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cases_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cases_primary_alert_id_fkey"
            columns: ["primary_alert_id"]
            isOneToOne: false
            referencedRelation: "alerts"
            referencedColumns: ["id"]
          },
        ]
      }
      media_articles: {
        Row: {
          body: string | null
          country: string | null
          crawl_method: string | null
          created_at: string
          credibility_score: number | null
          headline: string
          id: string
          ingested_at: string
          language: string | null
          model_version: string | null
          organization_id: string
          parser_version: string | null
          processing_status: Database["public"]["Enums"]["processing_status"]
          published_at: string | null
          raw_metadata: Json
          severity: Database["public"]["Enums"]["risk_severity"]
          source_id: string | null
          source_url: string | null
          summary: string | null
          updated_at: string
        }
        Insert: {
          body?: string | null
          country?: string | null
          crawl_method?: string | null
          created_at?: string
          credibility_score?: number | null
          headline: string
          id?: string
          ingested_at?: string
          language?: string | null
          model_version?: string | null
          organization_id: string
          parser_version?: string | null
          processing_status?: Database["public"]["Enums"]["processing_status"]
          published_at?: string | null
          raw_metadata?: Json
          severity?: Database["public"]["Enums"]["risk_severity"]
          source_id?: string | null
          source_url?: string | null
          summary?: string | null
          updated_at?: string
        }
        Update: {
          body?: string | null
          country?: string | null
          crawl_method?: string | null
          created_at?: string
          credibility_score?: number | null
          headline?: string
          id?: string
          ingested_at?: string
          language?: string | null
          model_version?: string | null
          organization_id?: string
          parser_version?: string | null
          processing_status?: Database["public"]["Enums"]["processing_status"]
          published_at?: string | null
          raw_metadata?: Json
          severity?: Database["public"]["Enums"]["risk_severity"]
          source_id?: string | null
          source_url?: string | null
          summary?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "media_articles_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "media_articles_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "media_sources"
            referencedColumns: ["id"]
          },
        ]
      }
      media_sources: {
        Row: {
          active: boolean
          api_endpoint: string | null
          country: string | null
          coverage_type: string | null
          created_at: string
          credibility_score: number
          description: string | null
          homepage_url: string | null
          id: string
          language: string | null
          last_updated_at: string | null
          organization_id: string
          region: string | null
          reliability_indicator: string
          rss_url: string | null
          source_name: string
          source_type: string
          typical_topics: string[]
          updated_at: string
        }
        Insert: {
          active?: boolean
          api_endpoint?: string | null
          country?: string | null
          coverage_type?: string | null
          created_at?: string
          credibility_score?: number
          description?: string | null
          homepage_url?: string | null
          id?: string
          language?: string | null
          last_updated_at?: string | null
          organization_id: string
          region?: string | null
          reliability_indicator?: string
          rss_url?: string | null
          source_name: string
          source_type: string
          typical_topics?: string[]
          updated_at?: string
        }
        Update: {
          active?: boolean
          api_endpoint?: string | null
          country?: string | null
          coverage_type?: string | null
          created_at?: string
          credibility_score?: number
          description?: string | null
          homepage_url?: string | null
          id?: string
          language?: string | null
          last_updated_at?: string | null
          organization_id?: string
          region?: string | null
          reliability_indicator?: string
          rss_url?: string | null
          source_name?: string
          source_type?: string
          typical_topics?: string[]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "media_sources_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      monitored_entities: {
        Row: {
          aliases: string[]
          created_at: string
          date_of_birth: string | null
          entity_type: Database["public"]["Enums"]["entity_type"]
          external_reference: string | null
          id: string
          identifiers: Json
          jurisdiction: string | null
          last_screened_at: string | null
          last_signal_at: string | null
          latest_signal: string | null
          name: string
          nationality: string | null
          notes: string | null
          organization_id: string
          owner_user_id: string | null
          risk_score: number
          status: string
          updated_at: string
          watchlist_memberships: string[]
        }
        Insert: {
          aliases?: string[]
          created_at?: string
          date_of_birth?: string | null
          entity_type?: Database["public"]["Enums"]["entity_type"]
          external_reference?: string | null
          id?: string
          identifiers?: Json
          jurisdiction?: string | null
          last_screened_at?: string | null
          last_signal_at?: string | null
          latest_signal?: string | null
          name: string
          nationality?: string | null
          notes?: string | null
          organization_id: string
          owner_user_id?: string | null
          risk_score?: number
          status?: string
          updated_at?: string
          watchlist_memberships?: string[]
        }
        Update: {
          aliases?: string[]
          created_at?: string
          date_of_birth?: string | null
          entity_type?: Database["public"]["Enums"]["entity_type"]
          external_reference?: string | null
          id?: string
          identifiers?: Json
          jurisdiction?: string | null
          last_screened_at?: string | null
          last_signal_at?: string | null
          latest_signal?: string | null
          name?: string
          nationality?: string | null
          notes?: string | null
          organization_id?: string
          owner_user_id?: string | null
          risk_score?: number
          status?: string
          updated_at?: string
          watchlist_memberships?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "monitored_entities_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_memberships: {
        Row: {
          created_at: string
          id: string
          membership_status: string
          organization_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          membership_status?: string
          organization_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          membership_status?: string
          organization_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_memberships_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          created_at: string
          id: string
          monitoring_status: string
          name: string
          sector: string
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          monitoring_status?: string
          name: string
          sector?: string
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          monitoring_status?: string
          name?: string
          sector?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          default_organization_id: string | null
          display_name: string | null
          id: string
          job_title: string | null
          preferences: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          default_organization_id?: string | null
          display_name?: string | null
          id?: string
          job_title?: string | null
          preferences?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          default_organization_id?: string | null
          display_name?: string | null
          id?: string
          job_title?: string | null
          preferences?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_default_organization_id_fkey"
            columns: ["default_organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      risk_signals: {
        Row: {
          article_id: string | null
          category: string
          confidence_score: number
          created_at: string
          description: string | null
          detected_at: string
          entity_id: string | null
          explanation: Json
          id: string
          organization_id: string
          severity: Database["public"]["Enums"]["risk_severity"]
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          article_id?: string | null
          category: string
          confidence_score?: number
          created_at?: string
          description?: string | null
          detected_at?: string
          entity_id?: string | null
          explanation?: Json
          id?: string
          organization_id: string
          severity: Database["public"]["Enums"]["risk_severity"]
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          article_id?: string | null
          category?: string
          confidence_score?: number
          created_at?: string
          description?: string | null
          detected_at?: string
          entity_id?: string | null
          explanation?: Json
          id?: string
          organization_id?: string
          severity?: Database["public"]["Enums"]["risk_severity"]
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "risk_signals_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "media_articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "risk_signals_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "monitored_entities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "risk_signals_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_org_member: {
        Args: { _organization_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      agent_status: "queued" | "running" | "completed" | "failed"
      alert_status:
        | "new"
        | "triaged"
        | "in_review"
        | "escalated"
        | "resolved"
        | "dismissed"
        | "false_positive"
      app_role: "admin" | "moderator" | "user"
      case_status:
        | "open"
        | "investigating"
        | "pending_review"
        | "resolved"
        | "closed"
      entity_type: "individual" | "company" | "vessel" | "asset" | "other"
      processing_status: "queued" | "processing" | "processed" | "failed"
      risk_severity: "low" | "medium" | "high" | "critical"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      agent_status: ["queued", "running", "completed", "failed"],
      alert_status: [
        "new",
        "triaged",
        "in_review",
        "escalated",
        "resolved",
        "dismissed",
        "false_positive",
      ],
      app_role: ["admin", "moderator", "user"],
      case_status: [
        "open",
        "investigating",
        "pending_review",
        "resolved",
        "closed",
      ],
      entity_type: ["individual", "company", "vessel", "asset", "other"],
      processing_status: ["queued", "processing", "processed", "failed"],
      risk_severity: ["low", "medium", "high", "critical"],
    },
  },
} as const
