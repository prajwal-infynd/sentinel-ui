import { CheckCircle, Loader2, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { MediaActivityItem, MediaFeedItem } from "@/lib/media-agent-data";

const severityColor = (severity: string) =>
  severity === "critical"
    ? "bg-destructive/10 text-destructive border-destructive/20"
    : severity === "high"
      ? "bg-warning/10 text-warning border-warning/20"
      : severity === "medium"
        ? "bg-primary/10 text-primary border-primary/20"
        : "bg-muted text-muted-foreground border-border";

const severityBorder = (severity: string) =>
  severity === "critical"
    ? "border-l-destructive"
    : severity === "high"
      ? "border-l-warning"
      : severity === "medium"
        ? "border-l-primary"
        : "border-l-muted-foreground";

export function MediaPanels({ articles, activities }: { articles: MediaFeedItem[]; activities: MediaActivityItem[] }) {
  const navigate = useNavigate();

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
      <div className="lg:col-span-3">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold">Live Media Stream</CardTitle>
              <div className="flex items-center gap-1.5">
                <div className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
                <span className="text-[10px] text-muted-foreground">Real-time</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {articles.map((article) => (
              <div
                key={article.id}
                className={`cursor-pointer rounded-lg border border-l-[3px] bg-card p-3 transition-[box-shadow,transform] hover:translate-x-0.5 hover:shadow-md active:scale-[0.99] ${severityBorder(article.severity)}`}
                onClick={() => navigate(`/media/article/${article.id}`)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium leading-tight">{article.headline}</p>
                    <div className="mt-1.5 flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground">{article.source}</span>
                      <span className="text-[10px] text-muted-foreground">·</span>
                      <span className="text-[10px] font-mono text-muted-foreground">{article.timestamp}</span>
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                      {article.riskTags.map((tag) => (
                        <Badge key={tag} variant="outline" className="h-4 px-1.5 py-0 text-[9px] capitalize">
                          {tag}
                        </Badge>
                      ))}
                      <Badge className={`h-4 px-1.5 py-0 text-[9px] uppercase ${severityColor(article.severity)}`}>{article.severity}</Badge>
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="text-xs font-bold font-mono">{article.riskScore}</div>
                    <div className="text-[9px] text-muted-foreground">risk</div>
                  </div>
                </div>
                <div className="mt-2 flex items-center gap-1 text-[9px]">
                  <span className="text-muted-foreground">Entities:</span>
                  {article.entities.slice(0, 2).map((entity) => (
                    <span key={entity} className="font-medium text-primary">{entity}</span>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-2">
        <Card className="h-full">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                <Zap className="h-3.5 w-3.5 text-accent" />
                Agent Activity
              </CardTitle>
              <span className="text-[10px] font-mono text-accent">Media Agent v1</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-1.5 font-mono text-[11px]">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-2 border-b border-border/50 py-1.5 last:border-0">
                  {activity.status === "active" ? (
                    <Loader2 className="mt-0.5 h-3 w-3 shrink-0 animate-spin text-accent" />
                  ) : (
                    <CheckCircle className="mt-0.5 h-3 w-3 shrink-0 text-success" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className={`text-[11px] leading-tight ${activity.status === "active" ? "text-foreground" : "text-muted-foreground"}`}>
                      {activity.action}
                    </p>
                    <p className="mt-0.5 text-[9px] text-muted-foreground/70">{activity.detail}</p>
                  </div>
                  <span className="shrink-0 text-[9px] text-muted-foreground">{activity.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
