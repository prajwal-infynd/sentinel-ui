import { Activity, Loader2, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { MediaDashboardSummary } from "@/lib/media-agent-data";

type MediaDashboardHeaderProps = {
  summary?: MediaDashboardSummary;
  onRun: () => void;
  isRunning: boolean;
};

export function MediaDashboardHeader({ summary, onRun, isRunning }: MediaDashboardHeaderProps) {
  return (
    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Adverse Media Monitoring</h1>
        <p className="mt-1 text-sm text-muted-foreground">Autonomous agent pipeline for adverse media ingestion, scoring, and alerting</p>
      </div>

      <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center">
        <div className="flex items-center gap-2 rounded-lg border border-success/20 bg-success/10 px-3 py-1.5">
          <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
          <span className="text-xs font-medium text-success">
            {summary?.activeAgents ? `${summary.activeAgents} agents active` : "Standby"}
          </span>
        </div>

        <div className="text-xs text-muted-foreground">
          <span className="font-mono">{summary?.sourcesScanned ?? 0}</span> sources scanned · <span className="font-mono">{summary?.articlesProcessed ?? 0}</span> articles processed
        </div>

        <Button size="sm" onClick={onRun} disabled={isRunning} className="gap-2">
          {isRunning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
          Run agents
        </Button>
      </div>
    </div>
  );
}
