import { Area, AreaChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { RiskCategoryPoint, SignalsPoint } from "@/lib/media-agent-data";

const chartStroke = "hsl(var(--muted-foreground))";
const chartGrid = "hsl(var(--border))";

export function MediaChartsRow({ signals, categories }: { signals: SignalsPoint[]; categories: RiskCategoryPoint[] }) {
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Media Signals Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[220px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={signals}>
                  <defs>
                    <linearGradient id="signalGradLive" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="alertGradLive" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={chartGrid} />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke={chartStroke} />
                  <YAxis tick={{ fontSize: 11 }} stroke={chartStroke} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: `1px solid ${chartGrid}`, fontSize: 12 }} />
                  <Area type="monotone" dataKey="signals" stroke="hsl(var(--primary))" fill="url(#signalGradLive)" strokeWidth={2} />
                  <Area type="monotone" dataKey="alerts" stroke="hsl(var(--destructive))" fill="url(#alertGradLive)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Risk Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={categories} dataKey="count" nameKey="category" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={2}>
                  {categories.map((entry) => (
                    <Cell key={entry.category} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 8, border: `1px solid ${chartGrid}`, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1">
            {categories.slice(0, 4).map((category) => (
              <div key={category.category} className="flex items-center gap-1.5 text-[10px]">
                <div className="h-2 w-2 rounded-full" style={{ background: category.color }} />
                <span className="truncate text-muted-foreground">{category.category}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
