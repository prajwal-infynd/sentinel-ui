import type { LucideIcon } from "lucide-react";
import { Activity, AlertTriangle, Newspaper, Target, TrendingUp, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import type { MediaDashboardSummary } from "@/lib/media-agent-data";

type KpiItem = {
  label: string;
  value: string;
  delta: string;
  icon: LucideIcon;
  color: string;
};

export function MediaKpiGrid({ summary }: { summary?: MediaDashboardSummary }) {
  const kpis: KpiItem[] = [
    { label: "Articles Ingested (24h)", value: String(summary?.articlesProcessed ?? 0), delta: "live", icon: Newspaper, color: "text-primary" },
    { label: "Risk Signals Detected", value: String(summary?.riskSignals ?? 0), delta: "scored", icon: Target, color: "text-destructive" },
    { label: "High-Risk Alerts", value: String(summary?.highRiskAlerts ?? 0), delta: "escalated", icon: AlertTriangle, color: "text-warning" },
    { label: "Entities Impacted", value: String(summary?.entitiesImpacted ?? 0), delta: "matched", icon: Users, color: "text-accent" },
    { label: "False Positive Rate", value: `${summary?.falsePositiveRate ?? 0}%`, delta: "resolved", icon: TrendingUp, color: "text-success" },
    { label: "Avg Confidence", value: `${summary?.avgConfidence ?? 0}%`, delta: "agent output", icon: Activity, color: "text-primary" },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
      {kpis.map((kpi) => (
        <Card key={kpi.label} className="transition-[box-shadow] hover:shadow-md">
          <CardContent className="p-4">
            <div className="mb-2 flex items-center justify-between">
              <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
              <span className="text-[10px] font-mono text-muted-foreground">{kpi.delta}</span>
            </div>
            <div className="text-xl font-bold font-mono tracking-tight">{kpi.value}</div>
            <div className="mt-1 text-[10px] text-muted-foreground">{kpi.label}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
