import { supabase } from "@/integrations/supabase/client";
import type { Json, Tables } from "@/integrations/supabase/types";

type ArticleRow = Tables<"media_articles">;
type AlertRow = Tables<"alerts">;
type RiskSignalRow = Tables<"risk_signals">;

type ArticleMatchLookup = Pick<Tables<"article_entity_matches">, "article_id" | "extracted_name" | "risk_tags" | "match_confidence">;
type AgentRunLookup = {
  id: string;
  agent_name: string;
  stage: string | null;
  status: Tables<"agent_runs">["status"];
  started_at: string;
  completed_at?: string | null;
  details: Json;
  input_count: number;
  output_count: number;
  average_confidence: number | null;
};

type AgentActivityLookup = Pick<Tables<"agent_runs">, "id" | "agent_name" | "stage" | "status" | "started_at" | "completed_at" | "details">;

type ArticleMetadata = {
  source_name?: string;
  risk_tags?: string[];
  entities?: string[];
  risk_score?: number;
  match_confidence?: number;
  matched_entity?: string;
  content?: string;
  summary?: string;
};

export type MediaDashboardSummary = {
  sourcesScanned: number;
  articlesProcessed: number;
  riskSignals: number;
  highRiskAlerts: number;
  entitiesImpacted: number;
  falsePositiveRate: number;
  avgConfidence: number;
  activeAgents: number;
};

export type MediaFeedItem = {
  id: string;
  headline: string;
  source: string;
  timestamp: string;
  severity: string;
  riskTags: string[];
  riskScore: number;
  entities: string[];
};

export type MediaActivityItem = {
  id: string;
  action: string;
  detail: string;
  status: "active" | "completed";
  time: string;
};

export type RiskCategoryPoint = {
  category: string;
  count: number;
  color: string;
};

export type SignalsPoint = {
  date: string;
  signals: number;
  alerts: number;
};

export type LiveMediaAlert = {
  id: string;
  severity: string;
  title: string;
  summary: string;
  generatedAt: string;
  confidenceScore: number;
  status: string;
  entityName: string;
  articleHeadline: string;
};

export type AgentOverview = {
  name: string;
  status: "running" | "idle" | "completed";
  processed: number;
  signals: number;
  accuracy: number;
  uptime: string;
  lastAction: string;
};

export type LiveArticleDetail = {
  id: string;
  headline: string;
  source: string;
  timestamp: string;
  language: string;
  credibilityScore: number;
  severity: string;
  content: string;
  summary: string;
  entities: string[];
  matchedEntity: string | null;
  matchConfidence: number;
  riskScore: number;
  riskTags: string[];
  trace: Array<{ label: string; value: string }>;
};

const CATEGORY_COLORS = [
  "hsl(var(--destructive))",
  "hsl(var(--warning))",
  "hsl(var(--primary))",
  "hsl(var(--accent))",
  "hsl(var(--success))",
  "hsl(var(--muted-foreground))",
];

const DAY_MS = 24 * 60 * 60 * 1000;

const asMetadata = (value: Json | null): ArticleMetadata => {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return value as unknown as ArticleMetadata;
};

const formatRelativeTime = (value?: string | null) => {
  if (!value) return "—";
  const diffMs = Date.now() - new Date(value).getTime();
  const diffMin = Math.max(1, Math.floor(diffMs / 60000));
  if (diffMin < 60) return `${diffMin} min ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours} hr ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays} day${diffDays === 1 ? "" : "s"} ago`;
};

const severityWeight = (severity: string) =>
  severity === "critical" ? 92 : severity === "high" ? 78 : severity === "medium" ? 58 : 31;

async function fetchArticleMatches(articleIds: string[]) {
  if (!articleIds.length) return [] as ArticleMatchLookup[];

  const { data, error } = await supabase
    .from("article_entity_matches")
    .select("article_id, extracted_name, risk_tags, match_confidence")
    .in("article_id", articleIds);

  if (error) throw error;
  return (data ?? []) as ArticleMatchLookup[];
}

async function fetchEntityNames(entityIds: string[]) {
  if (!entityIds.length) return new Map<string, string>();

  const { data, error } = await supabase
    .from("monitored_entities")
    .select("id, name")
    .in("id", entityIds);

  if (error) throw error;
  return new Map((data ?? []).map((row) => [row.id, row.name]));
}

async function fetchArticleHeadlines(articleIds: string[]) {
  if (!articleIds.length) return new Map<string, string>();

  const { data, error } = await supabase
    .from("media_articles")
    .select("id, headline")
    .in("id", articleIds);

  if (error) throw error;
  return new Map((data ?? []).map((row) => [row.id, row.headline]));
}

export async function fetchMediaDashboardSummary(): Promise<MediaDashboardSummary> {
  const since = new Date(Date.now() - DAY_MS).toISOString();

  const [
    { count: sourcesScanned },
    { count: articlesProcessed },
    { count: riskSignals },
    { count: highRiskAlerts },
    { count: falsePositiveCount },
    { data: recentSignals },
    { data: recentAlerts },
    { count: activeAgents },
  ] = await Promise.all([
    supabase.from("media_sources").select("id", { count: "exact", head: true }).eq("active", true),
    supabase.from("media_articles").select("id", { count: "exact", head: true }).gte("ingested_at", since),
    supabase.from("risk_signals").select("id", { count: "exact", head: true }).gte("detected_at", since),
    supabase.from("alerts").select("id", { count: "exact", head: true }).gte("generated_at", since).in("severity", ["high", "critical"]),
    supabase.from("alerts").select("id", { count: "exact", head: true }).eq("status", "false_positive"),
    supabase.from("risk_signals").select("confidence_score, entity_id").gte("detected_at", since).limit(200),
    supabase.from("alerts").select("id").gte("generated_at", since).limit(200),
    supabase.from("agent_runs").select("id", { count: "exact", head: true }).eq("status", "running"),
  ]);

  const uniqueEntityIds = new Set((recentSignals ?? []).map((signal) => signal.entity_id).filter(Boolean));
  const avgConfidence = (recentSignals ?? []).length
    ? Number(
        (
          (recentSignals ?? []).reduce((sum, signal) => sum + Number(signal.confidence_score ?? 0), 0) /
          (recentSignals ?? []).length
        ).toFixed(1),
      )
    : 0;
  const falsePositiveRate = (recentAlerts?.length ?? 0) > 0
    ? Number((((falsePositiveCount ?? 0) / Math.max(recentAlerts?.length ?? 1, 1)) * 100).toFixed(1))
    : 0;

  return {
    sourcesScanned: sourcesScanned ?? 0,
    articlesProcessed: articlesProcessed ?? 0,
    riskSignals: riskSignals ?? 0,
    highRiskAlerts: highRiskAlerts ?? 0,
    entitiesImpacted: uniqueEntityIds.size,
    falsePositiveRate,
    avgConfidence,
    activeAgents: activeAgents ?? 0,
  };
}

export async function fetchMediaArticles(limit = 8): Promise<MediaFeedItem[]> {
  const { data, error } = await supabase
    .from("media_articles")
    .select("id, headline, ingested_at, severity, raw_metadata")
    .order("ingested_at", { ascending: false })
    .limit(limit);

  if (error) throw error;

  const matches = await fetchArticleMatches((data ?? []).map((article) => article.id));
  const groupedMatches = matches.reduce<Record<string, ArticleMatchLookup[]>>((acc, match) => {
    acc[match.article_id] ??= [];
    acc[match.article_id].push(match);
    return acc;
  }, {});

  return (data ?? []).map((article) => {
    const metadata = asMetadata(article.raw_metadata);
    const articleMatches = groupedMatches[article.id] ?? [];
    const entities = metadata.entities?.length
      ? metadata.entities
      : articleMatches.map((match) => match.extracted_name).filter(Boolean);
    const riskTags = metadata.risk_tags?.length
      ? metadata.risk_tags
      : Array.from(new Set(articleMatches.flatMap((match) => match.risk_tags ?? [])));

    return {
      id: article.id,
      headline: article.headline,
      source: metadata.source_name ?? "Monitored Source",
      timestamp: formatRelativeTime(article.ingested_at),
      severity: article.severity,
      riskTags,
      riskScore: Number(metadata.risk_score ?? severityWeight(article.severity)),
      entities: entities.slice(0, 3),
    };
  });
}

export async function fetchMediaAgentActivity(limit = 8): Promise<MediaActivityItem[]> {
  const { data, error } = await supabase
    .from("agent_runs")
    .select("id, agent_name, stage, status, started_at, completed_at, details")
    .order("started_at", { ascending: false })
    .limit(limit);

  if (error) throw error;

  return ((data ?? []) as AgentActivityLookup[]).map((run) => {
    const details = (run.details ?? {}) as Record<string, unknown>;
    return {
      id: run.id,
      action: `${run.agent_name} · ${run.stage ?? "Monitoring"}`,
      detail:
        typeof details.summary === "string"
          ? details.summary
          : typeof details.last_action === "string"
            ? details.last_action
            : "Cycle executed against live workspace data",
      status: run.status === "running" ? "active" : "completed",
      time: formatRelativeTime(run.completed_at ?? run.started_at),
    };
  });
}

export async function fetchMediaSignalsOverTime(): Promise<SignalsPoint[]> {
  const since = new Date(Date.now() - DAY_MS * 6).toISOString();
  const [signalsResult, alertsResult] = await Promise.all([
    supabase.from("risk_signals").select("detected_at").gte("detected_at", since).limit(500),
    supabase.from("alerts").select("generated_at").gte("generated_at", since).limit(500),
  ]);

  if (signalsResult.error) throw signalsResult.error;
  if (alertsResult.error) throw alertsResult.error;

  const points = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(Date.now() - DAY_MS * (6 - index));
    const key = day.toISOString().slice(0, 10);
    return {
      key,
      date: day.toLocaleDateString(undefined, { weekday: "short" }),
      signals: 0,
      alerts: 0,
    };
  });

  const pointMap = new Map(points.map((point) => [point.key, point]));

  for (const signal of signalsResult.data ?? []) {
    const key = signal.detected_at.slice(0, 10);
    const point = pointMap.get(key);
    if (point) point.signals += 1;
  }

  for (const alert of alertsResult.data ?? []) {
    const key = alert.generated_at.slice(0, 10);
    const point = pointMap.get(key);
    if (point) point.alerts += 1;
  }

  return points.map(({ key: _key, ...point }) => point);
}

export async function fetchMediaRiskCategories(): Promise<RiskCategoryPoint[]> {
  const { data, error } = await supabase
    .from("risk_signals")
    .select("category")
    .order("detected_at", { ascending: false })
    .limit(500);

  if (error) throw error;

  const counts = new Map<string, number>();
  for (const row of data ?? []) {
    counts.set(row.category, (counts.get(row.category) ?? 0) + 1);
  }

  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([category, count], index) => ({
      category,
      count,
      color: CATEGORY_COLORS[index % CATEGORY_COLORS.length],
    }));
}

export async function fetchMediaAlerts(limit = 12): Promise<LiveMediaAlert[]> {
  const { data, error } = await supabase
    .from("alerts")
    .select("id, severity, title, summary, generated_at, confidence_score, status, entity_id, article_id")
    .order("generated_at", { ascending: false })
    .limit(limit);

  if (error) throw error;

  const entityIds = Array.from(new Set((data ?? []).map((row) => row.entity_id).filter(Boolean))) as string[];
  const articleIds = Array.from(new Set((data ?? []).map((row) => row.article_id).filter(Boolean))) as string[];

  const [entityNames, articleHeadlines] = await Promise.all([
    fetchEntityNames(entityIds),
    fetchArticleHeadlines(articleIds),
  ]);

  return (data ?? []).map((alert: AlertRow) => ({
    id: alert.id,
    severity: alert.severity,
    title: alert.title,
    summary: alert.summary ?? "High-priority media event generated by the monitoring pipeline.",
    generatedAt: alert.generated_at,
    confidenceScore: Number(alert.confidence_score ?? 0),
    status: alert.status,
    entityName: alert.entity_id ? entityNames.get(alert.entity_id) ?? "Matched entity" : "Matched entity",
    articleHeadline: alert.article_id ? articleHeadlines.get(alert.article_id) ?? "Source article" : "Source article",
  }));
}

export async function fetchAgentOverview(): Promise<AgentOverview[]> {
  const { data, error } = await supabase
    .from("agent_runs")
    .select("id, agent_name, stage, status, input_count, output_count, average_confidence, started_at, details")
    .order("started_at", { ascending: false })
    .limit(120);

  if (error) throw error;

  const grouped = new Map<string, AgentRunLookup[]>();
  for (const run of data ?? []) {
    grouped.set(run.agent_name, [...(grouped.get(run.agent_name) ?? []), run]);
  }

  return Array.from(grouped.entries()).map(([name, runs]) => {
    const latest = runs[0];
    const successful = runs.filter((run) => run.status !== "failed").length;
    const avgConfidence = runs.length
      ? runs.reduce((sum, run) => sum + Number(run.average_confidence ?? 0), 0) / runs.length
      : 0;
    const details = (latest.details ?? {}) as Record<string, unknown>;

    return {
      name,
      status: runs.some((run) => run.status === "running")
        ? "running"
        : latest.status === "completed"
          ? "completed"
          : "idle",
      processed: runs.reduce((sum, run) => sum + Number(run.input_count ?? 0), 0),
      signals: runs.reduce((sum, run) => sum + Number(run.output_count ?? 0), 0),
      accuracy: Number(avgConfidence.toFixed(0)),
      uptime: `${runs.length ? ((successful / runs.length) * 100).toFixed(1) : "100.0"}%`,
      lastAction:
        typeof details.last_action === "string"
          ? details.last_action
          : latest.stage ?? "Monitoring cycle updated",
    };
  });
}

export async function fetchMediaArticleDetail(id: string): Promise<LiveArticleDetail | null> {
  const { data: article, error } = await supabase
    .from("media_articles")
    .select("id, headline, summary, body, source_url, language, credibility_score, severity, ingested_at, raw_metadata, crawl_method, parser_version, model_version")
    .eq("id", id)
    .maybeSingle();

  if (error) throw error;
  if (!article) return null;

  const [matchesResult, signalsResult] = await Promise.all([
    supabase
      .from("article_entity_matches")
      .select("extracted_name, risk_tags, match_confidence")
      .eq("article_id", id),
    supabase
      .from("risk_signals")
      .select("category, confidence_score, detected_at")
      .eq("article_id", id),
  ]);

  if (matchesResult.error) throw matchesResult.error;
  if (signalsResult.error) throw signalsResult.error;

  const metadata = asMetadata(article.raw_metadata);
  const matches = matchesResult.data ?? [];
  const signals = signalsResult.data ?? [];
  const riskTags = metadata.risk_tags?.length
    ? metadata.risk_tags
    : Array.from(new Set([...matches.flatMap((match) => match.risk_tags ?? []), ...signals.map((signal) => signal.category)]));

  return {
    id: article.id,
    headline: article.headline,
    source: metadata.source_name ?? "Monitored Source",
    timestamp: formatRelativeTime(article.ingested_at),
    language: article.language ?? "English",
    credibilityScore: Number(article.credibility_score ?? 0),
    severity: article.severity,
    content: metadata.content ?? article.body ?? article.summary ?? "No article body stored for this ingestion cycle.",
    summary: metadata.summary ?? article.summary ?? "Automated agent summary will appear here as new cycles complete.",
    entities: metadata.entities?.length ? metadata.entities : matches.map((match) => match.extracted_name),
    matchedEntity: metadata.matched_entity ?? matches[0]?.extracted_name ?? null,
    matchConfidence: Number(metadata.match_confidence ?? matches[0]?.match_confidence ?? 0),
    riskScore: Number(metadata.risk_score ?? severityWeight(article.severity)),
    riskTags,
    trace: [
      { label: "Ingested", value: new Date(article.ingested_at).toLocaleString() },
      { label: "Crawl method", value: article.crawl_method ?? "Automated workspace agent" },
      { label: "Parser version", value: article.parser_version ?? "Agent pipeline" },
      { label: "Model version", value: article.model_version ?? "Rules + heuristics" },
      { label: "Signals generated", value: String(signals.length) },
      { label: "Source URL", value: article.source_url ?? "Internal generated source item" },
    ],
  };
}

export async function runMediaAgent() {
  const { data, error } = await supabase.functions.invoke("media-agent-run", {
    body: { mode: "manual" },
  });

  if (error) throw error;
  return data;
}