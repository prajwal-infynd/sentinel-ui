import { supabase } from "@/integrations/supabase/client";
import type { Json, TablesInsert } from "@/integrations/supabase/types";

export type MonitoredEntityImportRow = {
  name: string;
  entityType?: string | null;
  jurisdiction?: string | null;
  nationality?: string | null;
  dateOfBirth?: string | null;
  externalReference?: string | null;
  aliases?: string[];
  watchlistMemberships?: string[];
  riskScore?: number | null;
  notes?: string | null;
  identifiers?: Record<string, unknown>;
};

export type DashboardSummary = {
  organizationName: string;
  entityCount: number;
  alertCount: number;
  highRiskAlertCount: number;
  articleCount: number;
  openCaseCount: number;
  avgRiskScore: number;
  activeAgentRuns: number;
};

export async function fetchDashboardSummary() {
  const [
    { data: profile },
    { count: entityCount },
    { count: alertCount },
    { count: highRiskAlertCount },
    { count: articleCount },
    { count: openCaseCount },
    { data: entities },
    { count: activeAgentRuns },
  ] = await Promise.all([
    supabase.from("profiles").select("default_organization_id, organizations(name)").limit(1).maybeSingle(),
    supabase.from("monitored_entities").select("id", { count: "exact", head: true }),
    supabase.from("alerts").select("id", { count: "exact", head: true }),
    supabase.from("alerts").select("id", { count: "exact", head: true }).in("severity", ["high", "critical"]),
    supabase.from("media_articles").select("id", { count: "exact", head: true }),
    supabase.from("cases").select("id", { count: "exact", head: true }).in("status", ["open", "investigating", "pending_review"]),
    supabase.from("monitored_entities").select("risk_score").limit(200),
    supabase.from("agent_runs").select("id", { count: "exact", head: true }).eq("status", "running"),
  ]);

  const avgRiskScore = entities?.length
    ? Number((entities.reduce((sum, entity) => sum + Number(entity.risk_score ?? 0), 0) / entities.length).toFixed(1))
    : 0;

  return {
    organizationName:
      ((profile as { organizations?: { name?: string } | { name?: string }[] } | null)?.organizations as { name?: string })?.name ??
      "Monitoring Workspace",
    entityCount: entityCount ?? 0,
    alertCount: alertCount ?? 0,
    highRiskAlertCount: highRiskAlertCount ?? 0,
    articleCount: articleCount ?? 0,
    openCaseCount: openCaseCount ?? 0,
    avgRiskScore,
    activeAgentRuns: activeAgentRuns ?? 0,
  } satisfies DashboardSummary;
}

export async function fetchEntities() {
  const { data, error } = await supabase
    .from("monitored_entities")
    .select("id, name, entity_type, jurisdiction, risk_score, latest_signal, last_screened_at, status")
    .order("risk_score", { ascending: false })
    .limit(20);

  if (error) throw error;
  return data ?? [];
}

export async function importMonitoredEntities(rows: MonitoredEntityImportRow[]) {
  if (!rows.length) return { imported: 0 };

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("default_organization_id")
    .limit(1)
    .maybeSingle();

  if (profileError) throw profileError;
  if (!profile?.default_organization_id) {
    throw new Error("No default organization is available for this user.");
  }

  const entityPayload = rows.map<TablesInsert<"monitored_entities">>((row) => ({
    organization_id: profile.default_organization_id,
    owner_user_id: null,
    name: row.name,
    entity_type:
      row.entityType === "individual" || row.entityType === "company" || row.entityType === "vessel" || row.entityType === "asset" || row.entityType === "other"
        ? row.entityType
        : "company",
    jurisdiction: row.jurisdiction ?? null,
    nationality: row.nationality ?? null,
    date_of_birth: row.dateOfBirth ?? null,
    external_reference: row.externalReference ?? null,
    aliases: row.aliases ?? [],
    watchlist_memberships: row.watchlistMemberships ?? [],
    risk_score: Number.isFinite(row.riskScore) ? Number(row.riskScore) : 0,
    notes: row.notes ?? null,
    identifiers: (row.identifiers ?? {}) as Json,
  }));

  const { error } = await supabase.from("monitored_entities").insert(entityPayload);
  if (error) throw error;

  return { imported: entityPayload.length };
}

export async function fetchAlerts() {
  const { data, error } = await supabase
    .from("alerts")
    .select("id, title, summary, severity, generated_at, confidence_score, status, monitored_entities(name), media_articles(headline)")
    .order("generated_at", { ascending: false })
    .limit(20);

  if (error) throw error;
  return data ?? [];
}

export async function fetchAgentRuns() {
  const { data, error } = await supabase
    .from("agent_runs")
    .select("id, agent_name, stage, status, started_at, details, output_count, average_confidence")
    .order("started_at", { ascending: false })
    .limit(20);

  if (error) throw error;
  return data ?? [];
}

export async function fetchInvestigationSnapshot() {
  const { data: alert, error: alertError } = await supabase
    .from("alerts")
    .select(`
      *,
      monitored_entities (*),
      media_articles (*),
      risk_signals (*)
    `)
    .order("generated_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (alertError) throw alertError;

  const { data: caseRecord, error: caseError } = await supabase
    .from("cases")
    .select("*")
    .order("opened_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (caseError) throw caseError;

  const { data: notes, error: notesError } = await supabase
    .from("analyst_notes")
    .select("id, body, created_at")
    .order("created_at", { ascending: false })
    .limit(5);

  if (notesError) throw notesError;

  return {
    alert,
    caseRecord,
    notes: notes ?? [],
  };
}