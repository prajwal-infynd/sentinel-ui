import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

type Source = {
  id: string;
  source_name: string;
  country: string | null;
  source_type: string;
  credibility_score: number;
};

type Entity = {
  id: string;
  name: string;
  entity_type: string;
  jurisdiction: string | null;
  risk_score: number;
};

type Profile = {
  default_organization_id: string | null;
};

const riskCatalog = [
  { category: "fraud", severity: "critical", title: "Fraud exposure detected", description: "Potential fraud-related allegations surfaced in monitored coverage." },
  { category: "corruption", severity: "high", title: "Corruption indicator detected", description: "Coverage suggests potential corruption or bribery exposure." },
  { category: "sanctions exposure", severity: "high", title: "Sanctions-adjacent relationship detected", description: "Entity appears connected to a sanctions-relevant network." },
  { category: "money laundering", severity: "critical", title: "AML concern detected", description: "Reported transaction patterns indicate possible laundering risk." },
];

const summaryLine = (entity: Entity, source: Source, category: string) =>
  `${entity.name} surfaced in ${source.source_name} with ${category} indicators during the latest ingestion cycle.`;

function randomFrom<T>(items: T[], seed: number) {
  return items[seed % items.length];
}

function buildArticle(entity: Entity, source: Source, risk: (typeof riskCatalog)[number], cycle: number) {
  const score = Math.min(97, Math.max(46, Math.round(entity.risk_score + source.credibility_score / 4)));
  const confidence = Math.min(99, Math.max(71, Math.round(score + 4)));
  const headline = `${entity.name} flagged by ${source.source_name} for ${risk.category}`;
  const body = `${entity.name}, a monitored ${entity.entity_type}, was referenced in new ${source.source_type.toLowerCase()} coverage from ${source.source_name}. The report links the entity to ${risk.category} concerns across ${entity.jurisdiction ?? "multiple"} jurisdictions. Automated extraction and portfolio matching raised the item for immediate analyst review.`;
  const summary = summaryLine(entity, source, risk.category);

  return {
    headline,
    summary,
    body,
    score,
    confidence,
    riskTags: [risk.category, entity.risk_score > 75 ? "portfolio risk uplift" : "enhanced due diligence"],
    metadata: {
      source_name: source.source_name,
      entities: [entity.name],
      risk_tags: [risk.category, entity.risk_score > 75 ? "portfolio risk uplift" : "enhanced due diligence"],
      risk_score: score,
      match_confidence: confidence,
      matched_entity: entity.name,
      content: body,
      summary,
      cycle,
      generated_by: "media-agent-run",
    },
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      throw new Error("Backend environment is not configured for agent execution.");
    }

    const authClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await authClient.auth.getClaims(token);

    if (claimsError || !claimsData?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub;
    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    const { data: profile, error: profileError } = await adminClient
      .from("profiles")
      .select("default_organization_id")
      .eq("user_id", userId)
      .maybeSingle<Profile>();

    if (profileError) throw profileError;
    if (!profile?.default_organization_id) {
      return new Response(JSON.stringify({ error: "No default organization configured." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const organizationId = profile.default_organization_id;

    const [{ data: sources, error: sourcesError }, { data: entities, error: entitiesError }] = await Promise.all([
      adminClient
        .from("media_sources")
        .select("id, source_name, country, source_type, credibility_score")
        .eq("organization_id", organizationId)
        .eq("active", true)
        .order("credibility_score", { ascending: false })
        .limit(4),
      adminClient
        .from("monitored_entities")
        .select("id, name, entity_type, jurisdiction, risk_score")
        .eq("organization_id", organizationId)
        .order("risk_score", { ascending: false })
        .limit(6),
    ]);

    if (sourcesError) throw sourcesError;
    if (entitiesError) throw entitiesError;
    if (!sources?.length || !entities?.length) {
      return new Response(JSON.stringify({ error: "Add sources and monitored entities before running the agents." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const agentNames = [
      "Media Crawl Agent",
      "NLP Extraction Agent",
      "Entity Matching Agent",
      "Risk Scoring Agent",
      "Alerting Agent",
    ];

    const cycle = Date.now();
    const createdArticles: string[] = [];
    const createdSignals: string[] = [];
    const createdAlerts: string[] = [];

    for (let index = 0; index < agentNames.length; index += 1) {
      const agentName = agentNames[index];
      const entity = randomFrom(entities as Entity[], cycle + index);
      const source = randomFrom(sources as Source[], cycle + index * 3);
      const risk = randomFrom(riskCatalog, cycle + index * 5);
      const articleDraft = buildArticle(entity, source, risk, cycle);

      const { data: run, error: runError } = await adminClient
        .from("agent_runs")
        .insert({
          organization_id: organizationId,
          agent_name: agentName,
          stage: index === 0 ? "ingestion" : index === 1 ? "extraction" : index === 2 ? "matching" : index === 3 ? "scoring" : "alerting",
          status: "running",
          input_count: 1,
          output_count: 0,
          average_confidence: articleDraft.confidence,
          details: {
            summary: `Executing ${agentName.toLowerCase()} for ${entity.name}`,
            last_action: articleDraft.summary,
          },
        })
        .select("id")
        .single();

      if (runError) throw runError;

      const { data: article, error: articleError } = await adminClient
        .from("media_articles")
        .insert({
          organization_id: organizationId,
          source_id: source.id,
          headline: articleDraft.headline,
          summary: articleDraft.summary,
          body: articleDraft.body,
          source_url: `https://example.com/generated/${cycle}-${index}`,
          language: "English",
          country: source.country ?? "Global",
          severity: risk.severity,
          credibility_score: source.credibility_score,
          processing_status: "processed",
          crawl_method: "agent_run",
          parser_version: "media-agent-v1",
          model_version: "heuristic-pipeline-v1",
          raw_metadata: articleDraft.metadata,
        })
        .select("id")
        .single();

      if (articleError) throw articleError;
      createdArticles.push(article.id);

      const { data: signal, error: signalError } = await adminClient
        .from("risk_signals")
        .insert({
          organization_id: organizationId,
          entity_id: entity.id,
          article_id: article.id,
          category: risk.category,
          severity: risk.severity,
          confidence_score: articleDraft.confidence,
          title: risk.title,
          description: risk.description,
          explanation: {
            source: source.source_name,
            entity: entity.name,
            score: articleDraft.score,
            cycle,
          },
          status: "open",
        })
        .select("id")
        .single();

      if (signalError) throw signalError;
      createdSignals.push(signal.id);

      const { error: matchError } = await adminClient.from("article_entity_matches").insert({
        article_id: article.id,
        entity_id: entity.id,
        extracted_name: entity.name,
        extraction_confidence: articleDraft.confidence,
        match_confidence: articleDraft.confidence,
        risk_tags: articleDraft.riskTags,
        context_snippet: articleDraft.summary,
      });

      if (matchError) throw matchError;

      const { data: alert, error: alertError } = await adminClient
        .from("alerts")
        .insert({
          organization_id: organizationId,
          entity_id: entity.id,
          article_id: article.id,
          signal_id: signal.id,
          severity: risk.severity,
          status: "new",
          confidence_score: articleDraft.confidence,
          title: `${entity.name} · ${risk.title}`,
          summary: articleDraft.summary,
          recommendation: risk.severity === "critical" ? "Escalate for analyst review immediately." : "Queue for analyst validation and enrichment.",
        })
        .select("id")
        .single();

      if (alertError) throw alertError;
      createdAlerts.push(alert.id);

      const { error: entityUpdateError } = await adminClient
        .from("monitored_entities")
        .update({
          latest_signal: `${risk.category} · ${source.source_name}`,
          last_signal_at: new Date().toISOString(),
          last_screened_at: new Date().toISOString(),
          risk_score: Math.min(99, Math.max(entity.risk_score, articleDraft.score)),
        })
        .eq("id", entity.id)
        .eq("organization_id", organizationId);

      if (entityUpdateError) throw entityUpdateError;

      const { error: runUpdateError } = await adminClient
        .from("agent_runs")
        .update({
          status: "completed",
          output_count: 1,
          completed_at: new Date().toISOString(),
          details: {
            summary: articleDraft.summary,
            last_action: `Created article, signal, and alert for ${entity.name}`,
            entity: entity.name,
            source: source.source_name,
            risk_category: risk.category,
          },
        })
        .eq("id", run.id);

      if (runUpdateError) throw runUpdateError;
    }

    return new Response(
      JSON.stringify({
        articlesCreated: createdArticles.length,
        signalsCreated: createdSignals.length,
        alertsCreated: createdAlerts.length,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      },
    );
  } catch (error) {
    console.error("media-agent-run error", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
