CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');
CREATE TYPE public.entity_type AS ENUM ('individual', 'company', 'vessel', 'asset', 'other');
CREATE TYPE public.risk_severity AS ENUM ('low', 'medium', 'high', 'critical');
CREATE TYPE public.alert_status AS ENUM ('new', 'triaged', 'in_review', 'escalated', 'resolved', 'dismissed', 'false_positive');
CREATE TYPE public.case_status AS ENUM ('open', 'investigating', 'pending_review', 'resolved', 'closed');
CREATE TYPE public.agent_status AS ENUM ('queued', 'running', 'completed', 'failed');
CREATE TYPE public.processing_status AS ENUM ('queued', 'processing', 'processed', 'failed');

CREATE TABLE public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  sector TEXT NOT NULL DEFAULT 'banking',
  monitoring_status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  default_organization_id UUID REFERENCES public.organizations(id) ON DELETE SET NULL,
  display_name TEXT,
  avatar_url TEXT,
  job_title TEXT,
  preferences JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

CREATE TABLE public.organization_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  membership_status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, user_id)
);

CREATE TABLE public.monitored_entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  owner_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  external_reference TEXT,
  name TEXT NOT NULL,
  entity_type public.entity_type NOT NULL DEFAULT 'company',
  jurisdiction TEXT,
  date_of_birth DATE,
  nationality TEXT,
  aliases TEXT[] NOT NULL DEFAULT '{}',
  identifiers JSONB NOT NULL DEFAULT '{}'::jsonb,
  watchlist_memberships TEXT[] NOT NULL DEFAULT '{}',
  risk_score NUMERIC(5,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  latest_signal TEXT,
  notes TEXT,
  last_screened_at TIMESTAMPTZ,
  last_signal_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.media_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  source_name TEXT NOT NULL,
  country TEXT,
  region TEXT,
  language TEXT,
  source_type TEXT NOT NULL,
  credibility_score NUMERIC(5,2) NOT NULL DEFAULT 50,
  reliability_indicator TEXT NOT NULL DEFAULT 'medium',
  coverage_type TEXT,
  homepage_url TEXT,
  rss_url TEXT,
  api_endpoint TEXT,
  description TEXT,
  typical_topics TEXT[] NOT NULL DEFAULT '{}',
  active BOOLEAN NOT NULL DEFAULT true,
  last_updated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.media_articles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  source_id UUID REFERENCES public.media_sources(id) ON DELETE SET NULL,
  headline TEXT NOT NULL,
  summary TEXT,
  body TEXT,
  source_url TEXT,
  language TEXT,
  country TEXT,
  severity public.risk_severity NOT NULL DEFAULT 'medium',
  credibility_score NUMERIC(5,2),
  published_at TIMESTAMPTZ,
  ingested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processing_status public.processing_status NOT NULL DEFAULT 'queued',
  crawl_method TEXT,
  parser_version TEXT,
  model_version TEXT,
  raw_metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.article_entity_matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  article_id UUID NOT NULL REFERENCES public.media_articles(id) ON DELETE CASCADE,
  entity_id UUID REFERENCES public.monitored_entities(id) ON DELETE CASCADE,
  extracted_name TEXT NOT NULL,
  extraction_confidence NUMERIC(5,2) NOT NULL DEFAULT 0,
  match_confidence NUMERIC(5,2),
  context_snippet TEXT,
  risk_tags TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.risk_signals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  entity_id UUID REFERENCES public.monitored_entities(id) ON DELETE CASCADE,
  article_id UUID REFERENCES public.media_articles(id) ON DELETE SET NULL,
  category TEXT NOT NULL,
  severity public.risk_severity NOT NULL,
  confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
  title TEXT NOT NULL,
  description TEXT,
  explanation JSONB NOT NULL DEFAULT '{}'::jsonb,
  detected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  status TEXT NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  entity_id UUID REFERENCES public.monitored_entities(id) ON DELETE CASCADE,
  article_id UUID REFERENCES public.media_articles(id) ON DELETE SET NULL,
  signal_id UUID REFERENCES public.risk_signals(id) ON DELETE SET NULL,
  assigned_to UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  summary TEXT,
  recommendation TEXT,
  severity public.risk_severity NOT NULL,
  confidence_score NUMERIC(5,2) NOT NULL DEFAULT 0,
  status public.alert_status NOT NULL DEFAULT 'new',
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  acknowledged_at TIMESTAMPTZ,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE SEQUENCE public.case_number_seq START 1000;

CREATE TABLE public.cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  entity_id UUID REFERENCES public.monitored_entities(id) ON DELETE SET NULL,
  primary_alert_id UUID REFERENCES public.alerts(id) ON DELETE SET NULL,
  assignee_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  case_number TEXT NOT NULL UNIQUE DEFAULT ('CASE-' || lpad(nextval('public.case_number_seq')::text, 6, '0')),
  title TEXT NOT NULL,
  summary TEXT,
  severity public.risk_severity NOT NULL DEFAULT 'medium',
  status public.case_status NOT NULL DEFAULT 'open',
  opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at TIMESTAMPTZ,
  resolution_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.case_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.cases(id) ON DELETE CASCADE,
  alert_id UUID NOT NULL REFERENCES public.alerts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (case_id, alert_id)
);

CREATE TABLE public.analyst_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  case_id UUID REFERENCES public.cases(id) ON DELETE CASCADE,
  alert_id UUID REFERENCES public.alerts(id) ON DELETE CASCADE,
  article_id UUID REFERENCES public.media_articles(id) ON DELETE CASCADE,
  author_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.agent_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  agent_name TEXT NOT NULL,
  stage TEXT,
  status public.agent_status NOT NULL DEFAULT 'queued',
  input_count INTEGER NOT NULL DEFAULT 0,
  output_count INTEGER NOT NULL DEFAULT 0,
  average_confidence NUMERIC(5,2),
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  );
$$;

CREATE OR REPLACE FUNCTION public.is_org_member(_organization_id UUID, _user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.organization_memberships
    WHERE organization_id = _organization_id
      AND user_id = _user_id
      AND membership_status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_org_id UUID;
  display_value TEXT;
  email_local TEXT;
  org_slug_base TEXT;
BEGIN
  display_value := COALESCE(NEW.raw_user_meta_data ->> 'display_name', split_part(NEW.email, '@', 1));
  email_local := lower(regexp_replace(split_part(NEW.email, '@', 1), '[^a-zA-Z0-9]+', '-', 'g'));
  org_slug_base := trim(both '-' from email_local);

  INSERT INTO public.organizations (name, slug)
  VALUES (
    COALESCE(display_value, 'New Workspace') || ' Workspace',
    org_slug_base || '-' || substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)
  )
  RETURNING id INTO new_org_id;

  INSERT INTO public.profiles (user_id, default_organization_id, display_name)
  VALUES (NEW.id, new_org_id, display_value);

  INSERT INTO public.organization_memberships (organization_id, user_id)
  VALUES (new_org_id, NEW.id);

  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'user');

  RETURN NEW;
END;
$$;

CREATE TRIGGER update_organizations_updated_at
BEFORE UPDATE ON public.organizations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_monitored_entities_updated_at
BEFORE UPDATE ON public.monitored_entities
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_media_sources_updated_at
BEFORE UPDATE ON public.media_sources
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_media_articles_updated_at
BEFORE UPDATE ON public.media_articles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_risk_signals_updated_at
BEFORE UPDATE ON public.risk_signals
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_alerts_updated_at
BEFORE UPDATE ON public.alerts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_cases_updated_at
BEFORE UPDATE ON public.cases
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_analyst_notes_updated_at
BEFORE UPDATE ON public.analyst_notes
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_agent_runs_updated_at
BEFORE UPDATE ON public.agent_runs
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE INDEX idx_profiles_user_id ON public.profiles(user_id);
CREATE INDEX idx_profiles_default_org ON public.profiles(default_organization_id);
CREATE INDEX idx_org_memberships_org_user ON public.organization_memberships(organization_id, user_id);
CREATE INDEX idx_entities_org ON public.monitored_entities(organization_id);
CREATE INDEX idx_entities_owner ON public.monitored_entities(owner_user_id);
CREATE INDEX idx_entities_status ON public.monitored_entities(status);
CREATE INDEX idx_entities_risk_score ON public.monitored_entities(risk_score DESC);
CREATE INDEX idx_sources_org ON public.media_sources(organization_id);
CREATE INDEX idx_articles_org ON public.media_articles(organization_id);
CREATE INDEX idx_articles_source ON public.media_articles(source_id);
CREATE INDEX idx_articles_published_at ON public.media_articles(published_at DESC);
CREATE INDEX idx_article_matches_article ON public.article_entity_matches(article_id);
CREATE INDEX idx_article_matches_entity ON public.article_entity_matches(entity_id);
CREATE INDEX idx_signals_org ON public.risk_signals(organization_id);
CREATE INDEX idx_signals_entity ON public.risk_signals(entity_id);
CREATE INDEX idx_signals_detected_at ON public.risk_signals(detected_at DESC);
CREATE INDEX idx_alerts_org ON public.alerts(organization_id);
CREATE INDEX idx_alerts_entity ON public.alerts(entity_id);
CREATE INDEX idx_alerts_status ON public.alerts(status);
CREATE INDEX idx_alerts_generated_at ON public.alerts(generated_at DESC);
CREATE INDEX idx_cases_org ON public.cases(organization_id);
CREATE INDEX idx_cases_status ON public.cases(status);
CREATE INDEX idx_case_alerts_case ON public.case_alerts(case_id);
CREATE INDEX idx_case_alerts_alert ON public.case_alerts(alert_id);
CREATE INDEX idx_notes_org ON public.analyst_notes(organization_id);
CREATE INDEX idx_notes_case ON public.analyst_notes(case_id);
CREATE INDEX idx_agent_runs_org ON public.agent_runs(organization_id);
CREATE INDEX idx_agent_runs_status ON public.agent_runs(status);

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organization_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monitored_entities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.article_entity_matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.risk_signals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.case_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analyst_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile or admins can view all profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can create their own profile or admins can create profiles"
ON public.profiles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can update their own profile or admins can update all profiles"
ON public.profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view their roles or admins can view all roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles"
ON public.user_roles
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can view their organization memberships"
ON public.organization_memberships
FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage organization memberships"
ON public.organization_memberships
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can view their organizations"
ON public.organizations
FOR SELECT
TO authenticated
USING (public.is_org_member(id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage organizations"
ON public.organizations
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access entities in their organizations"
ON public.monitored_entities
FOR SELECT
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can create entities in their organizations"
ON public.monitored_entities
FOR INSERT
TO authenticated
WITH CHECK ((public.is_org_member(organization_id, auth.uid()) AND (owner_user_id IS NULL OR owner_user_id = auth.uid())) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can update entities in their organizations"
ON public.monitored_entities
FOR UPDATE
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK ((public.is_org_member(organization_id, auth.uid()) AND (owner_user_id IS NULL OR owner_user_id = auth.uid() OR owner_user_id <> auth.uid())) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can delete entities in their organizations"
ON public.monitored_entities
FOR DELETE
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access media sources in their organizations"
ON public.media_sources
FOR ALL
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access media articles in their organizations"
ON public.media_articles
FOR ALL
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access article matches through organization membership"
ON public.article_entity_matches
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.media_articles ma
    WHERE ma.id = article_id
      AND (public.is_org_member(ma.organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.media_articles ma
    WHERE ma.id = article_id
      AND (public.is_org_member(ma.organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
  )
);

CREATE POLICY "Members can access risk signals in their organizations"
ON public.risk_signals
FOR ALL
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access alerts in their organizations"
ON public.alerts
FOR ALL
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access cases in their organizations"
ON public.cases
FOR ALL
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access case alerts through their cases"
ON public.case_alerts
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.cases c
    WHERE c.id = case_id
      AND (public.is_org_member(c.organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.cases c
    WHERE c.id = case_id
      AND (public.is_org_member(c.organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
  )
);

CREATE POLICY "Members can view notes in their organizations"
ON public.analyst_notes
FOR SELECT
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can create notes in their organizations"
ON public.analyst_notes
FOR INSERT
TO authenticated
WITH CHECK ((public.is_org_member(organization_id, auth.uid()) AND author_user_id = auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authors can update their notes and admins can update all notes"
ON public.analyst_notes
FOR UPDATE
TO authenticated
USING ((public.is_org_member(organization_id, auth.uid()) AND author_user_id = auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK ((public.is_org_member(organization_id, auth.uid()) AND author_user_id = auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authors can delete their notes and admins can delete all notes"
ON public.analyst_notes
FOR DELETE
TO authenticated
USING ((public.is_org_member(organization_id, auth.uid()) AND author_user_id = auth.uid()) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members can access agent runs in their organizations"
ON public.agent_runs
FOR ALL
TO authenticated
USING (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.is_org_member(organization_id, auth.uid()) OR public.has_role(auth.uid(), 'admin'));